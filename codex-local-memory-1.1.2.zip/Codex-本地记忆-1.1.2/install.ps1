﻿param(
  [string]$SourceRoot = $PSScriptRoot,
  [string]$InstallRoot = (Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex/local-memory-marketplace'),
  [string]$DataRoot = (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Codex/LocalMemory'),
  [string]$CodexPath = 'codex',
  [string]$NodePath = 'node'
)
$ErrorActionPreference = 'Stop'
$source = (Resolve-Path -LiteralPath $SourceRoot).Path
$dest = [IO.Path]::GetFullPath($InstallRoot)
$nodeCommand = (Get-Command $NodePath -ErrorAction Stop).Source
$codexCommand = (Get-Command $CodexPath -ErrorAction Stop).Source
if (-not (Test-Path -LiteralPath (Join-Path $source '.agents/plugins/marketplace.json'))) { throw '缺少本地目录清单。' }
if (Test-Path -LiteralPath $dest) { throw "目标已存在，未覆盖：$dest。升级前请备份并选择新的安装目录。" }
New-Item -ItemType Directory -Path $dest -Force | Out-Null
$activeCodexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex' }
$existingConfig = Join-Path $activeCodexHome 'config.toml'
if (Test-Path -LiteralPath $existingConfig) { Copy-Item -LiteralPath $existingConfig -Destination (Join-Path $dest 'pre-install-config.toml') }
Copy-Item -LiteralPath (Join-Path $source '.agents') -Destination $dest -Recurse
Copy-Item -LiteralPath (Join-Path $source 'plugins') -Destination $dest -Recurse
$plugin = Join-Path $dest 'plugins/local-conversation-memory'
$utf8 = New-Object System.Text.UTF8Encoding $false
$runtime = @{node=$nodeCommand; dataRoot=[IO.Path]::GetFullPath($DataRoot)} | ConvertTo-Json
[IO.File]::WriteAllText((Join-Path $plugin 'runtime.json'), $runtime, $utf8)
# Record exact, quoted paths for the local hook commands; no trust database is modified.
$hookCommand = '"' + $nodeCommand.Replace('\','/') + '" "' + (Join-Path $plugin 'scripts/hook.mjs').Replace('\','/') + '"'
$hook = @{type='command';command=$hookCommand;commandWindows=$hookCommand;timeout=15}
$hooks = @{description='本地意图识别与回答完成后的实际用量提醒；不读取旧记忆、不发送外部请求。';hooks=@{UserPromptSubmit=@(@{hooks=@($hook)});Stop=@(@{hooks=@($hook)})}}
New-Item -ItemType Directory -Force -Path (Join-Path $plugin 'hooks') | Out-Null
[IO.File]::WriteAllText((Join-Path $plugin 'hooks/hooks.json'), ($hooks | ConvertTo-Json -Depth 10), $utf8)
& $codexCommand plugin marketplace add $dest --json
if ($LASTEXITCODE -ne 0) { throw '目录注册失败，源文件保留便于诊断。' }
& $codexCommand plugin add 'local-conversation-memory@personal-local-memory' --json
if ($LASTEXITCODE -ne 0) { throw '插件安装失败，已注册目录保留便于重试。' }
& $nodeCommand (Join-Path $plugin 'scripts/memory.mjs') doctor
if ($LASTEXITCODE -ne 0) { throw '运行时检查失败。' }
Write-Output '插件已安装。新对话加载；如果当前客户端未刷新，请重启 Codex。可选自动提醒需通过 /hooks 审阅并信任，安装器不替你写入信任。'
