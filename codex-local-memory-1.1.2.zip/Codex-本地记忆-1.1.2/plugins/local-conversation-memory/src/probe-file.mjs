import fs from 'node:fs';
// Open locally without reading file contents; detect missing paths, permissions and directories.
export function probeFile(file) {
 let fd;
 try {
  if(typeof file!=='string'||!file||/^(?:\\\\|\/\/)/.test(file))return {available:false,unavailableReason:'无法定位可读取的本地文件'};
  const actual=fs.realpathSync(file);
  if(/^(?:\\\\|\/\/)/.test(actual))return {available:false,unavailableReason:'网络路径不作为本地附件'};
  fd=fs.openSync(actual,'r');const stat=fs.fstatSync(fd);
  if(!stat.isFile())return {available:false,unavailableReason:'此路径不是文件'};
  if(stat.size>50*1024*1024)return {available:false,bytes:stat.size,unavailableReason:'超过单个附件 50 MiB 上限'};
  return {available:true,bytes:stat.size};
 }catch{return {available:false,unavailableReason:'文件不存在或当前没有读取权限'};}
 finally{if(fd!==undefined)fs.closeSync(fd);}
}
