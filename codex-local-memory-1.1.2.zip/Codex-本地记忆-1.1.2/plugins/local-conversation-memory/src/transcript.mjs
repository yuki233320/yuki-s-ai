import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {createReadStream} from 'node:fs';
import {createInterface} from 'node:readline';
import {extractPoints, mergePoints, titleSuggestion} from './extract.js';
import {probeFile} from './probe-file.mjs';
import {resourcesFrom} from './resources.js';

export const validId = s => typeof s === 'string' && /^[a-f0-9-]{36}$/i.test(s);
export const codexHome = () => process.env.CODEX_HOME || path.join(os.homedir(), '.codex');
export async function canonical(p) { return fs.realpath(path.resolve(p)); }

// Enumerate names only under session storage. Read exactly the matching thread, never other chats.
export async function findTranscript(session, home=codexHome()) {
  if (!validId(session)) throw Error('缺少有效的当前 Codex 对话 ID。');
  const matches=[];
  async function walk(dir,depth=0) {
    if(depth>4)return;
    for(const e of await fs.readdir(dir,{withFileTypes:true}).catch(e=>{if(e.code==='ENOENT')return [];throw e;})) {
      if(e.isSymbolicLink())continue;
      const p=path.join(dir,e.name);
      if(e.isDirectory())await walk(p,depth+1);
      else if(e.isFile()&&e.name.endsWith(`-${session}.jsonl`))matches.push(p);
    }
  }
  await walk(path.join(home,'sessions'));
  if(matches.length!==1)throw Error(`未找到唯一的当前对话 JSONL（${matches.length} 个）；不读取其他对话。`);
  return matches[0];
}

export function measuredCapacity(info,timestamp) {
  const u=info?.last_token_usage,w=info?.model_context_window;
  const valid=v=>Number.isSafeInteger(v)&&v>=0;
  if(!u || !valid(w)||w===0 || !['input_tokens','output_tokens','total_tokens'].every(k=>valid(u[k])) || u.input_tokens+u.output_tokens!==u.total_tokens || u.total_tokens>w || !valid(u.cached_input_tokens??0) || (u.cached_input_tokens??0)>u.input_tokens)
    return {status:'unknown',reason:'无有效、可核对的最新 token 用量和窗口。'};
  return {status:'measured',used:u.total_tokens,total:w,percent:Math.round(u.total_tokens/w*100),above70:BigInt(u.total_tokens)*100n>=BigInt(w)*70n,timestamp,
    basis:'最近一次模型请求 input_tokens（已含缓存）+ output_tokens / model_context_window；非实时逐 token 数值。'};
}

export async function readTranscript(file,session,cwd) {
  if(!validId(session))throw Error('无效对话 ID。');
  if((await fs.stat(file)).size>128*1024*1024)throw Error('当前转录超过 128 MiB，停止以避免不完整保存。');
  const project=await canonical(cwd);
  const messages=[],resources=new Map();let meta=null,seq=0,capacity={status:'unknown',reason:'尚无实际用量。'},omitted=0,points=[],malformed=0;
  const lines=createInterface({input:createReadStream(file,{encoding:'utf8'}),crlfDelay:Infinity});
  for await(const line of lines) {
    if(!line.trim())continue;
    let r;try{r=JSON.parse(line);}catch{malformed++;continue;}
    const p=r.payload;
    if(r.type==='session_meta')meta=p;
    if(r.type==='compacted'||(r.type==='event_msg'&&p?.type==='context_compacted'))capacity={status:'unknown',reason:'压缩之后等待新的实际用量。'};
    if(r.type==='turn_context')capacity={status:'unknown',reason:'新一轮或模型切换后等待新的实际用量。'};
    if(r.type==='event_msg'&&p?.type==='token_count'&&p.info)capacity=measuredCapacity(p.info,r.timestamp);
    if(r.type!=='response_item'||p?.type!=='message'||!['user','assistant'].includes(p.role)||p.channel==='summary'||p.channel==='analysis'||p.channel==='commentary')continue;
    const text=(p.content||[]).filter(b=>['input_text','output_text','text'].includes(b.type)).map(b=>b.text||'').join('\n');
    // These are host-injected records, not user conversation text.
    if(p.role==='user'&&/^\s*(?:<environment_context>|<permissions instructions>|# AGENTS\.md instructions)/u.test(text))continue;
    if(!text.trim())continue;
    seq++;messages.push({seq,role:p.role,text,timestamp:r.timestamp});
    const merged=mergePoints(points,extractPoints(text,{seq,role:p.role}));points=merged.points;omitted+=merged.omitted;
    for(const item of resourcesFrom([{type:'text',text}],seq)) {
      if(!item.path)continue;
      const candidate=path.resolve(project,item.path);
      // UNC/network drives are never followed. Local symlinks are checked again at copy time.
      if(/^\\\\|^\/\//.test(item.path))continue;
      const id=candidate.toLowerCase();
      resources.set(id,{id,path:candidate,name:path.basename(candidate),seq});
    }
  }
  if(!meta||meta.id!==session)throw Error('转录标识与当前对话不一致。');
  if((await canonical(meta.cwd)).toLowerCase()!==project.toLowerCase())throw Error('当前项目与对话所属项目不一致。请使用对话原始项目路径。');
  if(!messages.length)throw Error('转录中没有可识别的对话消息。');
  // An incomplete final line is normal while the host appends; don't silently save corrupt history.
  if(malformed)throw Error('转录存在未完成或损坏的 JSON 行，请稍后重试。');
  for(const r of resources.values()) {
    Object.assign(r,probeFile(r.path));
  }
  return {schema:1,session,project,messages,points,resources:[...resources.values()],capacity,omitted,suggestedName:titleSuggestion(points),createdAt:new Date().toISOString()};
}
