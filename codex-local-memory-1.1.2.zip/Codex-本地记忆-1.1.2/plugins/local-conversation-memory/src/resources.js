/** Discover only explicit references in this session; never crawl directories or URLs. */
export function resourcesFrom(content,seq) {
  const rows=[];
  for(const block of content||[]) {
    if((block.type==='file'||block.type==='image')&&block.attachment?.attachmentId) {
      const ref=block.attachment;
      rows.push({id:String(ref.attachmentId),kind:block.type,name:ref.name||`图片-${String(ref.attachmentId).slice(-8)}`,ref,seq});
    }
    if(block.type!=='text'||typeof block.text!=='string')continue;
    const text=block.text.replace(/^.*\b(?:ENOENT|ENOTDIR):[^\r\n]*$/gmu,'');
    // Exclude whole remote URLs before looking for drive letters (https: ends in s:).
    // This also prevents query strings such as ?file=C:/example.txt becoming attachments.
    const localText=text.replace(/\b(?!file:)[a-z][a-z0-9+.-]+:\/\/[^\s<>"`]+/giu,' ');
    const found=[];
    for(const m of text.matchAll(/\[[^\]\n]*\]\((?:<([^>]+)>|([^\n)]+))\)/gu))found.push(m[1]||m[2]);
    for(const m of localText.matchAll(/(?<![\p{L}\p{N}_:/\\])(?:[A-Za-z]:[\\/]|\.{1,2}[\\/])[^\r\n"<>|`]*?\.[A-Za-z0-9]{1,10}(?=[\s"<>`，。；;)]|$)/gu))found.push(m[0]);
    for(let file of found) {
      file=file.trim();
      if(/^(?!file:)[a-z][a-z0-9+.-]+:/i.test(file))continue;
      if(/^file:\/\//i.test(file)) { try{file=decodeURIComponent(new URL(file).pathname).replace(/^\/([A-Za-z]:)/,'$1');}catch{continue;} }
      if(!/\.[A-Za-z0-9]{1,10}$/.test(file))continue;
      rows.push({id:`path:${file}`,kind:'path',name:file.split(/[\\/]/).at(-1),path:file,seq});
    }
  }
  return [...new Map(rows.map(r=>[r.id,r])).values()];
}
export function mergeResources(previous,added) {
  return [...new Map([...previous,...added].map(r=>[r.id,r])).values()];
}
