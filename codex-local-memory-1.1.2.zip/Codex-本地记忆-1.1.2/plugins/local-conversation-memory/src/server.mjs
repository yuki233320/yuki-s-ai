import http from 'node:http';
import {probeFile} from './probe-file.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {pluginRoot,saveSelection,savePortableSelection,writeJson} from './storage.mjs';

export async function startReview({root,draft,operation,stateFile,onFinish=()=>{},ttlMs=30*60*1000}) {
  const token=randomBytes(32).toString('hex');let state='pending',busy=false,origin,timer;
  const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'self'"};
  const server=http.createServer(async(req,res)=>{
    const send=(status,data,type='application/json; charset=utf-8')=>{res.writeHead(status,{...headers,'Content-Type':type});res.end(typeof data==='string'?data:JSON.stringify(data));};
    try {
      if(req.headers.host!==new URL(origin).host)return send(403,{error:'不允许的 Host。'});
      const url=new URL(req.url,origin);
      if(req.method==='GET'&&['/','/ui.js','/ui.css'].includes(url.pathname)) {
        const file=url.pathname==='/'?'index.html':url.pathname.slice(1);
        return send(200,await fs.readFile(path.join(pluginRoot,'ui',file),'utf8'),file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.js')?'text/javascript; charset=utf-8':'text/css; charset=utf-8');
      }
      if(req.headers.authorization!==`Bearer ${token}`)return send(401,{error:'本机页面授权已失效，请重新打开命名窗口。'});
      if(req.headers.origin&&req.headers.origin!==origin)return send(403,{error:'拒绝跨站请求。'});
      if(req.method==='GET'&&url.pathname==='/draft')return send(200,{...draft,resources:draft.portable?draft.resources:draft.resources.map(r=>({...r,...probeFile(r.path)})),portable:undefined,messages:undefined,saveDirectory:path.resolve(root),operation,status:state});
      if(req.method!=='POST'||!['/save','/cancel'].includes(url.pathname))return send(404,{error:'没有此操作。'});
      if(!req.headers['content-type']?.startsWith('application/json'))return send(415,{error:'需要 JSON。'});
      if(state!=='pending'||busy)return send(409,{error:'操作已完成或正在保存。'});
      busy=true;
      try {
        let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>1024*1024)throw Error('提交内容过大。');}
        const selection=JSON.parse(body);
        const result=url.pathname==='/cancel'?{status:'cancelled'}:await (draft.portable?savePortableSelection:saveSelection)(root,draft,selection);
        if(result.status==='saved')await writeJson(path.join(root,'reminders',`${draft.session}.json`),{saved:true});
        state=result.status;clearTimeout(timer);await writeJson(stateFile,{operation,...result,finishedAt:new Date().toISOString()});
        send(200,result);setTimeout(()=>{server.close();onFinish(result);},1500).unref();
      }finally{busy=false;}
    }catch(e){send(400,{error:e.message});}
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  origin=`http://127.0.0.1:${server.address().port}`;
  const ready={operation,status:'pending',url:`${origin}/#token=${token}`,expiresAt:new Date(Date.now()+ttlMs).toISOString(),points:draft.points.length,attachments:draft.resources.length};
  await writeJson(stateFile,ready);
  const expire=async()=>{if(busy){timer=setTimeout(expire,1000);timer.unref();return;}state='expired';await writeJson(stateFile,{operation,status:'expired'});server.close();onFinish({status:'expired'});};
  timer=setTimeout(expire,ttlMs);timer.unref();
  return {server,ready,close:()=>{clearTimeout(timer);server.close();}};
}
