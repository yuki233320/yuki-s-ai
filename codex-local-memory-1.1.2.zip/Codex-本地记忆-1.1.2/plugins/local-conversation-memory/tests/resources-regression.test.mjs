import test from 'node:test';
import assert from 'node:assert/strict';
import {resourcesFrom} from '../src/resources.js';

test('remote URLs never become local drive paths, including Markdown and URL queries',()=>{
 const urls=[
  'https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.0-rc.2/packages/client/connection/src/browser-auth.ts',
  'http://example.com/test.pdf',
  'https://example.com/?file=C:/private/report.txt',
  'https://example.com/../report.txt',
  'ftp://example.com/image.png'
 ];
 for(const url of urls){
  assert.deepEqual(resourcesFrom([{type:'text',text:url}],1),[],url);
  assert.deepEqual(resourcesFrom([{type:'text',text:`[网页](${url})`}],1),[],url);
 }
});
test('remote links do not hide real Windows, relative and file URL attachments',()=>{
 const text=String.raw`https://github.com/test/file.ts
C:\资料 空格\报告.pdf
S:/资料/报告.txt
./local.txt
[本地](<C:\资料\附件.png>)
[文件](file:///C:/files/note.md)`;
 const paths=resourcesFrom([{type:'text',text}],2).map(x=>x.path);
 for(const p of [String.raw`C:\资料 空格\报告.pdf`,'S:/资料/报告.txt','./local.txt',String.raw`C:\资料\附件.png`,'C:/files/note.md'])assert.ok(paths.includes(p),p);
 assert.ok(paths.every(p=>!p.includes('github.com')));
});

test('reported filesystem errors are diagnostics, not new attachment references',()=>{
 assert.deepEqual(resourcesFrom([{type:'text',text:String.raw`ENOENT: no such file or directory, realpath 's:\github.com\deepseek-ai\browser-auth.ts'`}],1),[]);
});
