import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {readPortable,validatePortable,importDraft,makePortable,writePortable} from '../src/portable.mjs';
import {saveSelection,savePortableSelection,exportMemory,listMemories,recallMemory} from '../src/storage.mjs';
const root=await fs.mkdtemp(path.join(os.tmpdir(),'memory-portable-'));
test.after(()=>fs.rm(root,{recursive:true,force:true}));
export const select=d=>({name:d.name||d.suggestedName,confirmed:true,pointIds:d.points.map(p=>p.id),resourceIds:(d.resources||d.attachments.map((a,i)=>({id:`portable:${i}`}))).map(r=>r.id)});
test('Codex save emits complete portable file; another project imports and re-exports without data loss',async()=>{
  const a=path.join(root,'A'),b=path.join(root,'B');await fs.mkdir(a);await fs.mkdir(b);const file=path.join(a,'附件.txt');await fs.writeFile(file,'中文附件\noriginal');
  const draft={session:randomUUID(),project:a,omitted:0,points:Array.from({length:250},(_,i)=>({id:String(i),text:`原文决策 ${i}。`,category:'decision',source:{seq:1,role:'user'}})),messages:[{seq:1,role:'user',text:'完整的原始来源消息',timestamp:'2026-10-03T00:00:00Z'}],resources:[{id:'f',path:file,name:'附件.txt'}]};
  const saved=await saveSelection(path.join(root,'data'),draft,{name:'互通测试',confirmed:true,pointIds:draft.points.map(p=>p.id),resourceIds:['f']});
  const doc=readPortable(saved.portablePath);assert.equal(doc.points.length,250);assert.equal(doc.attachments.length,1);assert.equal(Buffer.from(doc.attachments[0].base64,'base64').toString(),'中文附件\noriginal');
  const incoming=importDraft(doc,{session:randomUUID(),project:b});const imported=await savePortableSelection(path.join(root,'data'),incoming,select(doc));
  const out=await exportMemory(path.join(root,'data'),b,{id:imported.id,file:path.join(root,'roundtrip.memory.json')});assert.deepEqual(readPortable(out.path),doc);
  assert.equal((await recallMemory(path.join(root,'data'),b,{id:imported.id,session:randomUUID()})).points.length,250);
  await assert.rejects(savePortableSelection(path.join(root,'data'),incoming,select(doc)),/同名|同一/);
});
test('invalid version, modified attachment, forged selection and missing confirmation fail',async()=>{
  const doc=readPortable(path.join(root,'roundtrip.memory.json'));
  assert.throws(()=>validatePortable({...doc,version:2}));assert.throws(()=>validatePortable({...doc,attachments:[{...doc.attachments[0],base64:Buffer.from('bad').toString('base64')}]}));
  const target=path.join(root,'C');await fs.mkdir(target);const draft=importDraft(doc,{session:randomUUID(),project:target});
  await assert.rejects(savePortableSelection(path.join(root,'data'),draft,{...select(doc),confirmed:false}));
  await assert.rejects(savePortableSelection(path.join(root,'data'),draft,{...select(doc),resourceIds:['outside']}));assert.deepEqual(await listMemories(path.join(root,'data'),target),[]);
});
test('attachment names cannot escape destination, binary data remains exact and export never overwrites',async()=>{
  const dir=path.join(root,'safe');await fs.mkdir(dir);const input=path.join(dir,'source');await fs.writeFile(input,Buffer.from([0,255,17]));
  const doc=makePortable({id:randomUUID(),name:'路径测试',sourceSession:'dsh-origin',project:'old-project',createdAt:new Date().toISOString(),points:[],sources:[]},'dsh',[{name:'../../escape.bin',path:input}]);
  const file=path.join(dir,'transfer.memory.json');writePortable(file,doc);assert.throws(()=>writePortable(file,doc));
  const saved=await savePortableSelection(path.join(root,'data'),importDraft(doc,{session:randomUUID(),project:dir}),select(doc));
  const record=JSON.parse(await fs.readFile(saved.path));assert(!record.attachments[0].file.includes('../'));assert.deepEqual(await fs.readFile(path.join(path.dirname(saved.path),record.attachments[0].file)),Buffer.from([0,255,17]));
});
