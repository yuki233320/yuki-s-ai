import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {probeFile} from '../src/probe-file.mjs';
test('attachment preflight accepts readable files and rejects missing files, directories and oversize files',()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'memory-probe-'));
 try {
  const file=path.join(root,'可读取 文件.txt');fs.writeFileSync(file,'test');assert.equal(probeFile(file).available,true);
  assert.equal(probeFile(root).available,false);assert.equal(probeFile(path.join(root,'missing.txt')).available,false);
  const fd=fs.openSync(path.join(root,'large.bin'),'w');fs.ftruncateSync(fd,50*1024*1024+1);fs.closeSync(fd);assert.equal(probeFile(path.join(root,'large.bin')).available,false);
  fs.unlinkSync(file);assert.equal(probeFile(file).available,false);assert.equal(probeFile(undefined).available,false);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
});
