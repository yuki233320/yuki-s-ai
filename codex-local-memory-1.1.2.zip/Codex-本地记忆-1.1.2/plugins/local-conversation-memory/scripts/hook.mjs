import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {readTranscript,validId} from '../src/transcript.mjs';
import {dataRoot,writeJson} from '../src/storage.mjs';
import {memoryIntent} from '../src/intent.js';

export async function handleHook(event,root) {
  if(!validId(event.session_id))return {};
  const file=path.join(root,'reminders',`${event.session_id}.json`);
  if(event.hook_event_name==='UserPromptSubmit') {
    if(/(?:别|不要|不再|不用).{0,8}(?:提醒|建议).{0,8}(?:记忆|保存)|(?:别|不要|不再|不用).{0,8}(?:记忆|保存).{0,8}提醒/u.test(event.prompt||'')) {
      await writeJson(file,{dismissed:true});return {};
    }
    if(memoryIntent(event.prompt))return {hookSpecificOutput:{hookEventName:'UserPromptSubmit',additionalContext:'用户表达了保存当前对话的意图。使用 local-memory 技能打开本机命名/附件确认页面；保存必须由用户在页面确认，不得自动点击。不要读取已有记忆。'}};
    return {};
  }
  if(event.hook_event_name!=='Stop'||event.stop_hook_active||!event.transcript_path)return {};
  const state=JSON.parse(await fs.readFile(file,'utf8').catch(e=>{if(e.code==='ENOENT')return '{}';throw e;}));
  if(state.dismissed||state.shown||state.saved)return {};
  const snapshot=await readTranscript(event.transcript_path,event.session_id,event.cwd);
  if(snapshot.capacity.status!=='measured'||!snapshot.capacity.above70)return {};
  await writeJson(file,{shown:true,used:snapshot.capacity.used,total:snapshot.capacity.total});
  return {systemMessage:`本次回答已完成。最近一次请求的上下文用量为 ${snapshot.capacity.percent}%（${snapshot.capacity.used}/${snapshot.capacity.total} token）。如需保存，可复制：使用 $local-memory 记住这段对话，名称为「记忆名称」。本对话只提醒一次；不确认不会保存。`};
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===path.resolve(process.argv[1])) {
  try{let input='';for await(const chunk of process.stdin){input+=chunk;if(input.length>2*1024*1024)throw Error('hook 输入过大');}process.stdout.write(JSON.stringify(await handleHook(JSON.parse(input),await dataRoot()))+'\n');}
  catch{process.stdout.write('{}\n');} // Never interrupt the user's answer on missing/changed telemetry.
}
