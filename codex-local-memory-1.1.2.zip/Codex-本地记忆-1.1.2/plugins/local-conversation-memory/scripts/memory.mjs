import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {findTranscript,readTranscript,validId} from '../src/transcript.mjs';
import {dataRoot,writeJson,listMemories,recallMemory,deleteMemory,exportMemory} from '../src/storage.mjs';
import {readPortable,importDraft} from '../src/portable.mjs';
import {startReview} from '../src/server.mjs';

const [cmd,...args]=process.argv.slice(2),opts={};
for(let i=0;i<args.length;i+=2){if(!/^--[a-z-]+$/.test(args[i])||args[i+1]===undefined)throw Error('参数必须为 --名称 值。');opts[args[i].slice(2)]=args[i+1];}
const output=o=>process.stdout.write(JSON.stringify(o)+'\n');
const root=await dataRoot();
const operationFile=id=>{if(!validId(id))throw Error('无效操作 ID。');return path.join(root,'operations',`${id}.json`);};
async function snapshot(){const session=opts.session||process.env.CODEX_THREAD_ID;return readTranscript(await findTranscript(session),session,opts.cwd||process.cwd());}
try {
  if(cmd==='prepare'||cmd==='import') {
    const session=opts.session||process.env.CODEX_THREAD_ID;
    if(!validId(session))throw Error('缺少当前对话 ID。');
    const draft=cmd==='import'?importDraft(readPortable(opts.file),{session,project:opts.cwd||process.cwd()}):await snapshot(),operation=randomUUID(),stateFile=operationFile(operation),draftFile=path.join(root,'operations',`${operation}.draft.json`);
    await writeJson(draftFile,draft);await writeJson(stateFile,{operation,status:'starting'});
    const child=spawn(process.execPath,[fileURLToPath(import.meta.url),'serve','--operation',operation],{detached:true,stdio:'ignore',windowsHide:true,env:{...process.env,CODEX_LOCAL_MEMORY_HOME:root}});
    let launchError;child.on('error',e=>{launchError=e;});child.unref();
    for(let i=0;i<100;i++) {
      if(launchError)throw launchError;
      const state=JSON.parse(await fs.readFile(stateFile,'utf8'));
      if(state.status==='pending'){output(state);process.exit(0);}
      if(state.status==='error')throw Error(state.error);
      await new Promise(r=>setTimeout(r,100));
    }
    throw Error('本机命名页面未能启动，请重试；未保存记忆。');
  }else if(cmd==='serve') {
    const stateFile=operationFile(opts.operation),draftFile=path.join(root,'operations',`${opts.operation}.draft.json`);
    try {
      const draft=JSON.parse(await fs.readFile(draftFile,'utf8'));await fs.rm(draftFile);
      await startReview({root,draft,operation:opts.operation,stateFile});
    }catch(e){await fs.rm(draftFile,{force:true});await writeJson(stateFile,{status:'error',error:e.message});throw e;}
  }else if(cmd==='status')output(JSON.parse(await fs.readFile(operationFile(opts.operation),'utf8')));
  else if(cmd==='list')output(await listMemories(root,opts.cwd||process.cwd()));
  else if(cmd==='recall')output(await recallMemory(root,opts.cwd||process.cwd(),{id:opts.id,name:opts.name,session:opts.session||process.env.CODEX_THREAD_ID}));
  else if(cmd==='delete')output(await deleteMemory(root,opts.cwd||process.cwd(),opts.id));
  else if(cmd==='export')output(await exportMemory(root,opts.cwd||process.cwd(),{id:opts.id,name:opts.name,file:opts.file}));
  else if(cmd==='capacity')output((await snapshot()).capacity);
  else if(cmd==='dismiss') {
    const session=opts.session||process.env.CODEX_THREAD_ID;if(!validId(session))throw Error('缺少有效会话 ID。');
    await writeJson(path.join(root,'reminders',`${session}.json`),{dismissed:true});output({status:'dismissed'});
  }else if(cmd==='doctor')output({version:'1.1.2',node:process.version,root,dependencies:'Node builtins only',network:'review UI only: 127.0.0.1; no external requests',nativeMemoriesModified:false});
  else throw Error('命令：prepare、import、export、status、list、recall、delete、capacity、dismiss、doctor。');
}catch(e){output({error:e.message});process.exitCode=1;}
