window.__ModuleLoader__.load({id:'dsh-cross-session-memory',factory(require){
  const React=require('react'),h=React.createElement;
  const zh={decision:'决策',todo:'待办',constraint:'约束',preference:'偏好',conclusion:'结论',data:'数据',fact:'事实',title:'保存本次对话记忆',name:'记忆名称（必填）',save:'确认保存到本地',cancel:'取消',open:'记忆当前对话',refresh:'刷新当前要点',points:'原文要点',files:'关联文件（默认全选）',all:'全选',none:'全不选',empty:'没有识别到关联文件；不会扫描其他目录。',local:'仅本地保存；不会上传记忆文件。新对话调用时只向当前模型提供选中的摘要。',source:'来源',user:'用户',assistant:'助手',note:'截取自原文，请核对；未选中项不保存。',omitted:'较早内容超出候选上限，未自动纳入；请分段记忆或查看原对话。',reminder:'当前对话实际上下文用量已达到 70%，回答已完成，可选择保存记忆。',copy:'复制记忆模板',dismiss:'本对话不再提醒',copied:'已复制',copyFail:'复制失败，请手动选中下方模板。',pending:'上下文：等待实际用量',measured:'上下文实测',stale:'上次实测（当前已变化）',saving:'正在保存…',unavailable:'记忆面板暂不可用',close:'关闭',portable:'同时写出跨端通用记忆文件（portable.memory.json，含附件，体积约增大 1/3；取消则不写，可事后用 /memory-export 补导出）',namePlaceholder:'请自定义命名该记忆',address:'记忆地址',memoryFile:'记忆库文件',portableFile:'跨端通用文件',portableMissing:'本次未生成跨端通用记忆文件（可用 /memory-export 补导出）',copyAddress:'复制地址',pointUnit:'条要点',fileUnit:'个文件',snapshot:'快照包含触发时已经完成的对话；回答完成后可点击“刷新当前要点”。'};
  const en={...zh};
  const style=`.dsh-memory{font:inherit;color:inherit;padding:2px 0;display:flex;gap:6px;align-items:center;flex-wrap:wrap}.dsh-memory .meter,.dsh-memory .trigger{border:0;background:0 0;border-radius:var(--dsw-radius-sm);color:var(--dsw-alias-label-tertiary);font-family:inherit;font-size:var(--dsh-content-font-size-secondary,13px);line-height:calc(20px + var(--dsh-content-font-delta-secondary,0px));font-variant-numeric:tabular-nums;white-space:nowrap;flex:none;align-items:center;gap:6px;padding:1px 8px;display:inline-flex}.dsh-memory .trigger{cursor:pointer}.dsh-memory .trigger:hover:not(:disabled),.dsh-memory .trigger[aria-expanded=true]{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}.dsh-memory .meter{cursor:default}.dsh-memory .ring .track{fill:none;stroke:var(--dsw-alias-border-l3);stroke-width:2px}.dsh-memory .ring .fill{fill:none;stroke:var(--dsw-alias-label-tertiary);stroke-width:2px;stroke-linecap:round}.dsh-memory button,.dsh-memory-dialog button{font:inherit;color:inherit;border:1px solid #8886;border-radius:7px;padding:6px 12px;background:transparent;cursor:pointer}.dsh-memory button:hover,.dsh-memory-dialog button:hover{background:#8882}.dsh-memory button:disabled,.dsh-memory-dialog button:disabled{opacity:.5;cursor:wait}.dsh-memory-dialog{font:inherit;color:var(--dsw-alias-text-primary,#20242b);background:var(--dsw-alias-background-primary,#fff);border:1px solid #8885;border-radius:14px;width:min(760px,90vw);max-height:85vh;padding:22px;box-shadow:0 16px 60px #0003}.dsh-memory-dialog::backdrop{background:#0006}.dsh-memory-dialog input[type=text]{font:inherit;box-sizing:border-box;width:100%;color:inherit;background:transparent;border:1px solid #8887;border-radius:7px;padding:10px;margin:7px 0 12px}.dsh-memory-dialog input[type=text]::placeholder{color:var(--dsw-alias-label-tertiary,#8a9c94);font-weight:400;opacity:1}.dsh-memory-dialog input[type=text]:focus::placeholder{opacity:0}.dsh-memory-dialog label.row{display:flex;align-items:flex-start;gap:8px;padding:8px 3px;border-bottom:1px solid #8882;word-break:break-word}.dsh-memory-dialog .list{max-height:24vh;overflow:auto;border:1px solid #8883;border-radius:8px;padding:4px 8px}.dsh-memory-dialog small{opacity:.7}.dsh-memory-dialog .actions{display:flex;gap:8px;justify-content:flex-end;margin-top:18px}.dsh-memory .notice{width:100%;font-size:.9em;overflow-wrap:anywhere;min-width:0}.dsh-memory .reminder{width:100%;padding:12px;background:#ce9d1714;border:1px solid #ce9d1755;border-radius:9px}.dsh-memory .template{display:block;user-select:all;margin:8px 0}.dsh-memory-dialog .error{color:#b33;margin:10px 0}.dsh-memory-dialog label.option{display:flex;align-items:flex-start;gap:8px;padding:10px 3px 0;margin-top:10px;border-top:1px solid #8882;word-break:break-word}.dsh-memory .address{border:0;background:0 0;border-radius:var(--dsw-radius-sm);color:var(--dsw-alias-label-tertiary);font-family:inherit;font-size:var(--dsh-content-font-size-secondary,13px);line-height:calc(20px + var(--dsh-content-font-delta-secondary,0px));font-variant-numeric:tabular-nums;white-space:nowrap;flex:none;align-items:center;gap:6px;padding:1px 8px;display:inline-flex;cursor:default;position:relative}.dsh-memory .address:hover,.dsh-memory .address:focus-visible{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}.dsh-memory .flash{font-size:var(--dsh-content-font-size-secondary,13px);color:var(--dsw-alias-label-tertiary);line-height:calc(20px + var(--dsh-content-font-delta-secondary,0px))}.dsh-memory .card{position:fixed;z-index:1200;box-sizing:border-box;width:min(400px,calc(100vw - 24px));padding:10px 12px;border-radius:var(--dsw-radius-lg);background:var(--dsw-specific-menu,var(--dsw-alias-background-primary,#fff));border:1px solid #8883;box-shadow:0 12px 40px #0003;color:var(--dsw-alias-label-secondary,#20242b);font-size:12px;line-height:1.65;white-space:normal;text-align:left;animation:dsh-memory-card-in .16s ease;transition:background .16s ease}.dsh-memory .card:hover{background:var(--dsw-alias-bg-layer-1,#fff)}@keyframes dsh-memory-card-in{from{opacity:0}to{opacity:1}}.dsh-memory .card .head{display:flex;align-items:baseline;gap:8px;justify-content:space-between}.dsh-memory .card .name{color:var(--dsw-alias-label-primary,#20242b);font-weight:600}.dsh-memory .card .meta{color:var(--dsw-alias-label-tertiary,#6b7280)}.dsh-memory .card .field{margin-top:8px}.dsh-memory .card .label{display:block;font-size:11px;color:var(--dsw-alias-label-tertiary,#6b7280)}.dsh-memory .card code{display:block;margin-top:2px;padding:4px 6px;border-radius:6px;background:#8881;font-family:inherit;font-size:11px;overflow-wrap:anywhere;user-select:text;cursor:text}.dsh-memory .card .note{margin-top:6px;font-size:11px;color:var(--dsw-alias-label-tertiary,#6b7280)}.dsh-memory .card .foot{display:flex;align-items:center;gap:8px;justify-content:flex-end;margin-top:10px}.dsh-memory .card .copy{font-size:11px;padding:4px 10px;border-radius:var(--dsw-radius-sm);border:1px solid #8884;background:transparent;color:inherit;cursor:pointer}.dsh-memory .card .copy:hover{background:var(--dsw-alias-interactive-bg-hover,#8882)}`;
  function MemoryPanel(props){
    const t=props.t||((k)=>zh[k]||k),source=props.source;
    const subscribe=React.useCallback(cb=>source.subscribe(cb),[source]),snapshot=React.useCallback(()=>source.getSnapshot(),[source]);
    const state=React.useSyncExternalStore(subscribe,snapshot,snapshot);
    const [name,setName]=React.useState(''),[points,setPoints]=React.useState([]),[files,setFiles]=React.useState([]),[busy,setBusy]=React.useState(false),[message,setMessage]=React.useState(''),[portable,setPortable]=React.useState(true);
    const dialog=React.useRef(null),draft=state?.draft;
    React.useEffect(()=>{if(draft){setName(draft.named?draft.suggestedName:'');setPoints(draft.points.map(p=>p.id));setFiles(draft.resources.map(r=>r.id));setPortable(true);setMessage('');dialog.current?.showModal();}else dialog.current?.close();},[draft?.id]);
    async function act(action,extra={}){
      if(busy)return;setBusy(true);setMessage('');
      try {const result=await props.send({action,...extra});if(result?.result?.kind==='error')setMessage(result.result.text);}
      catch(e){setMessage(e.message||t('unavailable'));}finally{setBusy(false);}
    }
    const toggle=(set,id)=>set(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);
    const monitor=state?.monitor;
    const meter=monitor?.status==='measured'?`${t('measured')} ${monitor.percent}%`:monitor?.percent!==undefined?`${t('stale')} ${monitor.percent}%`:t('pending');
    const detail=monitor?.used!==undefined?`${monitor.used} / ${monitor.total} tokens；${monitor.reason}`:monitor?.reason;
    // Ring geometry mirrors the native composer ContextMeter: 14px viewBox, 2px stroke, r=5.5.
    const circumference=2*Math.PI*5.5,percent=monitor?.percent;
    const ring=percent===undefined?null:h('svg',{className:'ring',viewBox:'0 0 14 14',width:'14',height:'14','aria-hidden':true,focusable:false},
      h('circle',{className:'track',cx:'7',cy:'7',r:'5.5'}),
      h('circle',{className:'fill',cx:'7',cy:'7',r:'5.5',strokeDasharray:`${circumference*Math.min(100,Math.max(0,percent))/100} ${circumference}`,transform:'rotate(-90 7 7)'}));
    // 记忆地址: the save result waits here, revealed only while the pointer rests on it.
    const saved=state?.lastSaved;
    const [flash,setFlash]=React.useState('');
    const [openCard,setOpenCard]=React.useState(false);
    const [cardAt,setCardAt]=React.useState(null);
    const [copyNote,setCopyNote]=React.useState('');
    const seenSaved=React.useRef(saved?.id??null);
    const addressRef=React.useRef(null);
    React.useEffect(()=>{
      if(!saved||saved.id===seenSaved.current)return;
      seenSaved.current=saved.id;
      setFlash(`已保存“${saved.name}”：${saved.points} ${t('pointUnit')}、${saved.resources} ${t('fileUnit')} · ${t('address')} ▸`);
      const timer=setTimeout(()=>setFlash(''),6000);
      return ()=>clearTimeout(timer);
    },[saved?.id]);
    const closeTimer=React.useRef(null);
    const cancelClose=()=>{if(closeTimer.current){clearTimeout(closeTimer.current);closeTimer.current=null;}};
    const openAddress=()=>{cancelClose();const box=addressRef.current?.getBoundingClientRect();if(box)setCardAt({left:Math.max(8,Math.min(box.left,window.innerWidth-408)),bottom:window.innerHeight-box.top+4});setOpenCard(true);};
    // The pointer must be able to travel from the trigger into the card, so leaving only
    // schedules the close and re-entering cancels it (mouseover bubbles from the card).
    const holdAddress=()=>cancelClose();
    const closeAddress=()=>{cancelClose();closeTimer.current=setTimeout(()=>{closeTimer.current=null;setOpenCard(false);setCopyNote('');},400);};
    const closeAddressNow=()=>{cancelClose();setOpenCard(false);setCopyNote('');};
    React.useEffect(()=>()=>cancelClose(),[]);
    const copyAddress=async()=>{try{await navigator.clipboard.writeText([saved.file,saved.portablePath].filter(Boolean).join('\n'));setCopyNote(t('copied'));}catch{setCopyNote(t('copyFail'));}};
    const template='/memory project "记忆名称"';
    const copy=async()=>{try{await navigator.clipboard.writeText(template);setMessage(t('copied'));}catch{setMessage(t('copyFail'));}};
    return h('div',{className:'dsh-memory'},h('style',null,style),
      h('span',{className:'meter',title:detail,'aria-label':meter},ring,h('span',null,meter)),h('button',{className:'trigger',type:'button',disabled:busy,'aria-haspopup':'dialog','aria-expanded':!!draft,onClick:()=>act('open')},t('open')),
      saved&&h('div',{ref:addressRef,className:'address',tabIndex:0,role:'button','aria-haspopup':'dialog','aria-expanded':openCard,'aria-label':t('address'),onMouseEnter:openAddress,onMouseOver:holdAddress,onMouseLeave:closeAddress,onFocus:openAddress,onBlur:e=>{if(!e.currentTarget.contains(e.relatedTarget))closeAddressNow();},onKeyDown:e=>{if(e.key==='Escape')closeAddressNow();}},
        h('svg',{className:'dsh-memory-icon',viewBox:'0 0 24 24',width:'14',height:'14',fill:'none',stroke:'currentColor',strokeWidth:1.7,strokeLinecap:'round',strokeLinejoin:'round','aria-hidden':true,focusable:false},h('path',{d:'M10.6 13.4a4 4 0 0 0 5.7 0l2.1-2.1a4 4 0 0 0-5.7-5.7l-1 1'}),h('path',{d:'M13.4 10.6a4 4 0 0 0-5.7 0l-2.1 2.1a4 4 0 0 0 5.7 5.7l1-1'})),
        h('span',null,t('address')),
        openCard&&cardAt&&h('div',{className:'card',role:'dialog','aria-label':t('address'),style:{left:cardAt.left,bottom:cardAt.bottom}},
          h('div',{className:'head'},h('span',{className:'name'},saved.name),h('span',{className:'meta'},`${saved.points} ${t('pointUnit')} · ${saved.resources} ${t('fileUnit')}`)),
          h('div',{className:'field'},h('span',{className:'label'},t('memoryFile')),h('code',null,saved.file)),
          h('div',{className:'field'},h('span',{className:'label'},t('portableFile')),saved.portablePath?h('code',null,saved.portablePath):h('span',{className:'meta'},t('portableMissing'))),
          saved.portableTrimmed>0&&h('div',{className:'note'},`仅含最近 250 条要点，另有 ${saved.portableTrimmed} 条未写入通用文件`),
          h('div',{className:'foot'},copyNote&&h('span',{className:'meta'},copyNote),h('button',{type:'button',className:'copy',onClick:copyAddress},t('copyAddress'))))),
      flash&&h('span',{className:'flash',role:'status'},flash),
      state?.reminder&&!state?.running&&h('div',{className:'reminder',role:'status'},h('div',null,t('reminder')),h('code',{className:'template'},template),h('button',{onClick:copy},t('copy')),h('button',{onClick:()=>act('open')},t('open')),h('button',{onClick:()=>act('dismiss')},t('dismiss'))),
      (state?.notice||message)&&h('div',{className:'notice',role:'status'},message||state.notice),
      h('dialog',{ref:dialog,className:'dsh-memory-dialog',onCancel:e=>{e.preventDefault();act('cancel');},'aria-labelledby':'dsh-memory-title'},
        h('h2',{id:'dsh-memory-title'},t('title')),
        h('label',null,t('name'),h('input',{type:'text',value:name,required:true,maxLength:100,placeholder:t('namePlaceholder'),onChange:e=>setName(e.target.value)})),
        h('small',null,t('snapshot')),h('p',null,t('local')),
        h('h3',null,`${t('points')} (${points.length}/${draft?.points.length||0})`),h('small',null,t('note')),
        h('button',{disabled:busy||draft?.imported,onClick:()=>act('refresh',{name})},t('refresh')),
        h('div',{className:'list'},...(draft?.points||[]).map(p=>h('label',{key:p.id,className:'row'},h('input',{type:'checkbox',checked:points.includes(p.id),onChange:()=>toggle(setPoints,p.id)}),h('span',null,`[${t(p.category)}] ${p.text}`,h('br'),h('small',null,`${t('source')} ${t(p.source.role)} #${p.source.seq}`))))),
        draft?.omitted>0&&h('p',null,`${draft.omitted}：${t('omitted')}`),
        h('h3',null,`${t('files')} (${files.length}/${draft?.resources.length||0})`),
        h('button',{onClick:()=>setFiles((draft?.resources||[]).map(r=>r.id))},t('all')),h('button',{onClick:()=>setFiles([])},t('none')),
        h('div',{className:'list'},...(draft?.resources||[]).map(r=>h('label',{key:r.id,className:'row'},h('input',{type:'checkbox',checked:files.includes(r.id),onChange:()=>toggle(setFiles,r.id)}),h('span',null,r.kind==='image'?'▧ ':'▤ ',r.name,h('br'),h('small',null,r.path||r.id)))),!draft?.resources.length&&h('p',null,t('empty'))),
        h('label',{className:'option'},h('input',{type:'checkbox',checked:portable,onChange:e=>setPortable(e.target.checked)}),h('span',null,t('portable'))),
        message&&h('p',{className:'error',role:'alert'},message),
        h('div',{className:'actions'},h('button',{disabled:busy,onClick:()=>act('cancel')},t('cancel')),h('button',{disabled:busy||!name.trim()||(!points.length&&!files.length),onClick:()=>act('commit',{draftId:draft.id,name,pointIds:points,resourceIds:files,portable})},busy?t('saving'):t('save')))));
  }
  return {inject:['slots','sessions','remote','remote.commands','locale'],apply(ctx){
    ctx.effect(()=>ctx.locale.register('crossSessionMemory',{zh,en}));
    ctx.slots.inject('conversation.composer.dock',()=>ctx.slots.register({name:'conversation.composer.dock',id:'cross-session-memory',order:20,locale:'crossSessionMemory',
      inject:sessionId=>{const binding=ctx.sessions.binding(sessionId);if(!binding)throw new Error('记忆面板缺少当前会话');return {source:binding.session.projections.faceOf('crossSessionMemory'),send:input=>ctx.remote.commands.execute(sessionId,'/memory-ui '+JSON.stringify(input),[],new AbortController().signal)};}
    },MemoryPanel));
  }};
}});

