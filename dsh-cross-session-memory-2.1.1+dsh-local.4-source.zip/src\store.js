import fs from 'node:fs';
import path from 'node:path';
import {randomUUID,createHash} from 'node:crypto';
import {MemoryStore,assertNotSensitive,projectFor} from './legacy-store.js';
import {makePortable,writePortable,selectPortable,materialize} from './portable.mjs';
import {CANDIDATE_LIMIT} from './extract.js';
/** The shared cross-end format (src/portable.mjs, byte-identical on both ends) carries at most 250 points. */
const PORTABLE_POINT_LIMIT=250;
/** Keep the newest points, matching what mergePoints itself keeps when a draft exceeds its limit. */
function exchangePoints(points) {const included=points.slice(-PORTABLE_POINT_LIMIT);return {included,trimmed:points.length-included.length};}
export {projectFor};
export class NamedMemoryStore extends MemoryStore {
  read(project) {
    const db=super.read(project);
    for(const r of db.entries) {
      if(r.name===undefined&&r.points===undefined&&r.resources===undefined)continue; // v1 record
      if(typeof r.name!=='string'||!r.name.trim()||r.name.length>100||!Array.isArray(r.points)||r.points.length>CANDIDATE_LIMIT||!Array.isArray(r.resources)
        ||r.points.some(p=>!p||typeof p.id!=='string'||typeof p.text!=='string'||p.text.length>1500||typeof p.category!=='string'||!p.source||!Number.isSafeInteger(p.source.seq)||typeof p.source.role!=='string')
        ||r.resources.some(f=>!f||typeof f.name!=='string'||typeof f.path!=='string'||!path.isAbsolute(f.path)||typeof f.sha256!=='string'||!/^[a-f0-9]{64}$/.test(f.sha256)||!Number.isSafeInteger(f.bytes)||f.bytes<0))throw new Error('命名记忆内容损坏，已停止读取和写入；原文件保留。');
    }
    return db;
  }
  async saveDraft(project,draft,input,attachments,signal) {
    const name=typeof input.name==='string'?input.name.trim():'';
    if(!name||name.length>100)throw new Error('请输入 1–100 字符的记忆名称。');
    if(!draft||input.draftId!==draft.id)throw new Error('此草稿已过期，请重新打开命名窗口。');
    if(!Array.isArray(input.pointIds)||!Array.isArray(input.resourceIds))throw new Error('请选择要保存的要点与文件。');
    const points=draft.points.filter(p=>input.pointIds.includes(p.id)),resources=draft.resources.filter(r=>input.resourceIds.includes(r.id));
    if(input.pointIds.some(id=>!draft.points.some(p=>p.id===id))||input.resourceIds.some(id=>!draft.resources.some(r=>r.id===id)))throw new Error('选择中有不属于本次对话草稿的条目。');
    if(!points.length&&!resources.length)throw new Error('请至少保留一条要点或一个文件。');
    if(input.portable!==undefined&&typeof input.portable!=='boolean')throw new Error('通用记忆文件选项无效。');
    assertNotSensitive({name,points});
    const id=randomUUID(),ownedRoot=path.join(path.dirname(this.location(project)),'assets');
    const folder=path.join(ownedRoot,id);fs.mkdirSync(folder,{recursive:true,mode:0o700});
    let committed=false;
    try {
      const savedResources=[];let totalBytes=0;
      for(const item of resources) {
        signal?.throwIfAborted();
        const leaf=item.name.replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').slice(0,100)||'attachment';
        if(/(?:^|[._-])(?:credentials|password|secret|id_rsa|\.env)(?:[._-]|$)/i.test(leaf))throw new Error(`文件 ${leaf} 疑似包含凭据，请取消勾选后重试。`);
        let source;
        if(item.kind==='path')source=path.resolve(project.cwd,item.path);
        else source=item.kind==='image'?attachments?.imageHostPath(item.ref):attachments?.fileHostPath(item.ref);
        if(!source)throw new Error(`无法定位本地文件“${item.name}”；请恢复文件或取消勾选，不会自动下载。`);
        let fd;
        try {fd=fs.openSync(source,'r');}catch{throw new Error(`无法读取“${item.name}”，请检查路径或取消勾选。`);}
        let bytes;
        try {
          const stat=fs.fstatSync(fd);
          if(!stat.isFile()||stat.size>50*1024*1024||totalBytes+stat.size>100*1024*1024)throw new Error('单文件上限 50 MiB，本次附件合计上限 100 MiB；请取消较大的文件。');
          bytes=fs.readFileSync(fd);
          if(bytes.length!==stat.size)throw new Error('读取时文件发生变化，请重试。');
        }finally{fs.closeSync(fd);}
        const hash=createHash('sha256').update(bytes).digest('hex');
        if(item.ref?.attachmentId&&String(item.ref.attachmentId)!==`sha256:${hash}`)throw new Error(`附件“${item.name}”完整性校验失败。`);
        if(/\.(txt|md|json|ya?ml|csv|env|ini|conf)$/i.test(leaf))assertNotSensitive(bytes.toString('utf8'));
        const saved=path.join(folder,`${savedResources.length+1}-${leaf}`);
        fs.writeFileSync(saved,bytes,{flag:'wx',mode:0o600});totalBytes+=bytes.length;
        savedResources.push({id:item.id,name:item.name,kind:item.kind,path:saved,bytes:bytes.length,sha256:hash,sourceSeq:item.seq});
      }
      signal?.throwIfAborted();
      const result=this.transaction(project,db=>{
        if(db.entries.length>=this.config.maxEntries)throw new Error('记忆容量已满，请先导出并删除不需要的记忆。');
        if(db.entries.some(r=>r.name===name&&r.status!=='archived'))throw new Error('已有同名记忆，请修改名称后确认，原记忆不会被覆盖。');
        const now=new Date().toISOString();
        const record={id,project:project.id,name,category:'fact',key:`snapshot:${id}`,summary:name,context:'',tags:[],sourceSession:project.sourceSession,
          createdAt:now,updatedAt:now,lastAccessedAt:now,importance:0.7,pinned:false,status:'active',conflicts:[],points,resources:savedResources,omitted:draft.omitted};
        // The panel's option decides whether this save also writes the self-contained exchange file.
        if(input.portable!==false) {
          const {included,trimmed}=exchangePoints(record.points);
          // Points the shared format cannot carry join `omitted`, so the other end sees why.
          const portable=makePortable({...record,points:included,extraction:{method:'verbatim',omitted:(record.omitted||0)+trimmed},project:project.cwd},'dsh',savedResources);
          record.portablePath=writePortable(path.join(folder,'portable.memory.json'),portable);
        }
        db.entries.push(record);this.log(db,'named-snapshot',[id],project);return record;
      });
      committed=true;
      const portableTrimmed=input.portable===false?0:Math.max(0,points.length-PORTABLE_POINT_LIMIT);
      return {id:result.id,name,file:this.location(project),portablePath:result.portablePath,points:points.length,resources:savedResources.length,portableTrimmed};
    }finally {
      if(!committed) {
        // Only our fresh UUID-owned directory; never remove a source attachment.
        const target=path.resolve(folder),parent=path.resolve(ownedRoot)+path.sep;
        if(target.startsWith(parent))fs.rmSync(target,{recursive:true,force:true});
      }
    }
  }
  savePortableSelection(project,portable,input) {
    if(input.portable!==undefined&&typeof input.portable!=='boolean')throw new Error('通用记忆文件选项无效。');
    const doc=selectPortable(portable,{...input,confirmed:true});
    assertNotSensitive({name:doc.name,points:doc.points,sources:doc.sources});
    const id=randomUUID(),owned=path.join(path.dirname(this.location(project)),'assets'),folder=path.join(owned,id);let committed=false;
    fs.mkdirSync(folder,{recursive:true});
    try {
      const resources=materialize(doc,folder).map((a,i)=>({...a,id:`portable:${i}`,kind:'path',sourceSeq:0}));
      // A bare import from another end still honours the same panel option.
      const portablePath=input.portable===false?undefined:writePortable(path.join(folder,'portable.memory.json'),doc);
      this.transaction(project,db=>{
        if(db.entries.length>=this.config.maxEntries)throw Error('记忆容量已满。');
        if(db.entries.some(r=>r.name===doc.name||r.id===doc.id||r.portableId===doc.id))throw Error('此项目已有同名或同一来源记忆；未覆盖。');
        const now=new Date().toISOString();
        db.entries.push({id,project:project.id,name:doc.name,category:'fact',key:`snapshot:${id}`,summary:doc.name,context:'',tags:[],sourceSession:doc.origin.session,createdAt:now,updatedAt:now,lastAccessedAt:now,importance:0.7,pinned:false,status:'active',conflicts:[],points:doc.points,resources,sources:doc.sources,portableId:doc.id,origin:doc.origin,originCreatedAt:doc.createdAt,extraction:doc.extraction,omitted:doc.extraction.omitted||0,portablePath});
        this.log(db,'portable-import',[id],project);
      });
      committed=true;return {id,name:doc.name,file:this.location(project),portablePath,points:doc.points.length,resources:resources.length};
    }finally{if(!committed&&path.resolve(folder).startsWith(path.resolve(owned)+path.sep))fs.rmSync(folder,{recursive:true,force:true});}
  }
  exportPortable(project,id,file) {
    const row=this.read(project).entries.find(r=>r.id===id);if(!row)throw Error('找不到当前项目的记忆 ID。');
    if(!row.points)throw Error('旧版单条记忆请先通过命名面板保存后再导出。');
    const owned=path.resolve(path.dirname(this.location(project)),'assets',row.id)+path.sep;
    for(const a of row.resources||[])if(!fs.realpathSync(a.path).startsWith(owned))throw Error('附件路径越过本条记忆目录。');
    const dir=path.join(this.root,project.user,'exports');fs.mkdirSync(dir,{recursive:true});
    const target=file?path.resolve(project.cwd,file):path.join(dir,`${id}-${randomUUID()}.memory.json`);
    // Export obeys the same shared-format ceiling the save path obeys.
    const {included,trimmed}=exchangePoints(row.points);
    writePortable(target,makePortable({...row,points:included,extraction:{method:'verbatim',omitted:(row.omitted||0)+trimmed},project:project.cwd},'dsh',row.resources||[]));
    return {file:target,name:row.name,points:included.length,trimmed};
  }
  context(project,query='') {
    this.maintain(project);
    const queryWords=new Set(query.toLowerCase().match(/[a-z0-9_]+|[\p{Script=Han}]{2}/gu)||[]);
    const records=this.read(project).entries.filter(r=>r.status==='active'&&r.sourceSession!==project.sourceSession);
    const rank=r=>{
      const all=`${r.name||''} ${r.summary} ${r.context} ${(r.points||[]).map(p=>p.text).join(' ')}`.toLowerCase();
      return [...queryWords].filter(w=>all.includes(w)).length;
    };
    const standing=r=>r.pinned||['preference','constraint'].includes(r.category)||(r.points||[]).some(p=>['preference','constraint'].includes(p.category));
    const sorted=records.sort((a,b)=>Number(standing(b))-Number(standing(a))||rank(b)-rank(a)||Date.parse(b.updatedAt)-Date.parse(a.updatedAt));
    const selected=[];let used=0;
    for(const r of sorted) {
      // A bounded recent fallback handles lexical misses without sending the whole file.
      const points=(r.points||[]).slice().sort((a,b)=>Number(['preference','constraint'].includes(b.category))-Number(['preference','constraint'].includes(a.category))).slice(0,8);
      const compact={id:r.id,name:r.name||r.summary,sourceSession:r.sourceSession,createdAt:r.createdAt,summary:r.summary,points:[],resources:(r.resources||[]).map(f=>({name:f.name,path:f.path})).slice(0,12)};
      if(!r.points&&r.context)compact.summary+=' '+r.context;
      for(const p of points) {const candidate={...compact,points:[...compact.points,p]};if(Buffer.byteLength(JSON.stringify(candidate))<this.config.maxContextBytes-used)compact.points.push(p);}
      const length=Buffer.byteLength(JSON.stringify(compact))+2;
      if(used+length>this.config.maxContextBytes)continue;
      selected.push(compact);used+=length;if(selected.length>=this.config.topK)break;
    }
    if(selected.length)this.transaction(project,db=>{for(const r of db.entries)if(selected.some(s=>s.id===r.id))r.lastAccessedAt=new Date().toISOString();});
    return selected;
  }
}
