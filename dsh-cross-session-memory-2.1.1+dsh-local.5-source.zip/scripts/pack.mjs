// Produce a standard npm-layout TGZ while preserving SemVer build metadata.
// Some package managers normalize 2.1.1+dsh-local.5 to 2.1.1 during pack.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync} from 'node:zlib';
const root=fileURLToPath(new URL('../',import.meta.url));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const entries=new Set(['package.json']);
function collect(rel){
  const full=path.resolve(root,rel);
  if(!full.startsWith(path.resolve(root)+path.sep))throw Error('Package path escapes source root');
  const st=fs.lstatSync(full);if(st.isSymbolicLink())throw Error('Symlinks are not packaged');
  if(st.isDirectory())for(const name of fs.readdirSync(full))collect(path.join(rel,name));
  else if(st.isFile())entries.add(rel.replaceAll('\\','/'));
}
for(const rel of manifest.files)collect(rel);
const chunks=[];
for(const rel of [...entries].sort()){
  const name='package/'+rel,body=fs.readFileSync(path.join(root,rel)),header=Buffer.alloc(512);
  if(Buffer.byteLength(name)>100)throw Error('Tar path too long: '+name);
  header.write(name);const oct=(offset,length,value)=>header.write(value.toString(8).padStart(length-1,'0')+'\0',offset,length);
  oct(100,8,0o644);oct(108,8,0);oct(116,8,0);oct(124,12,body.length);oct(136,12,0);
  header.fill(32,148,156);header.write('0',156);header.write('ustar\0',257);header.write('00',263);
  const sum=header.reduce((a,b)=>a+b,0);header.write(sum.toString(8).padStart(6,'0')+'\0 ',148,8);
  chunks.push(header,body,Buffer.alloc((512-body.length%512)%512));
}
chunks.push(Buffer.alloc(1024));
const destination=path.resolve(process.argv[2]||path.join(root,'dist'));fs.mkdirSync(destination,{recursive:true});
const file=path.join(destination,`${manifest.name}-${manifest.version}.tgz`);
fs.writeFileSync(file,gzipSync(Buffer.concat(chunks)));
console.log(file);
