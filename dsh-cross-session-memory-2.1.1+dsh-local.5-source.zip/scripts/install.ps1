﻿param(
  [Parameter(Mandatory=$true)][string]$PackagePath,
  [ValidatePattern('^[a-zA-Z0-9_-]+$')][string]$Profile = 'web',
  [string]$DshCommand = 'dsh'
)
$ErrorActionPreference = 'Stop'
# Use the invoking directory for relative paths. Never evaluate pasted path text as code.
$candidate = $PackagePath.Trim().Trim('"').Trim("'")
if ($candidate -match '^\[[^\]]*\]\((?:<([^>]+)>|(.+))\)$') {
  if ($Matches[1]) { $candidate = $Matches[1] } else { $candidate = $Matches[2] }
}
if ($candidate.StartsWith('file://')) { $candidate = ([uri]$candidate).LocalPath }
$resolved = (Resolve-Path -LiteralPath $candidate).Path
if (-not $resolved.EndsWith('.tgz', [StringComparison]::OrdinalIgnoreCase)) { throw '请选择 .tgz 安装包' }
if (-not (Test-Path -LiteralPath $resolved -PathType Leaf)) { throw '安装包不存在' }
if ($Profile -eq 'desktop') { Write-Host '桌面 profile 安装需使用桌面版提供的 CLI；请先完全退出桌面应用。' }
& $DshCommand plugin --profile $Profile add $resolved
if ($LASTEXITCODE -ne 0) { throw "DSH 安装失败，退出码 $LASTEXITCODE" }
Write-Host '安装命令成功。请启用插件；若提示重启，请重启，再进行功能验收。'
