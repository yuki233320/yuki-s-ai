import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
export function resolvePackage(input,cwd=process.cwd()) {
  if(typeof input!=='string')throw new Error('请提供 .tgz 文件路径');
  let value=input.trim();
  const link=/^\[[^\]]*\]\((?:<([^>]+)>|(.+))\)$/.exec(value);if(link)value=link[1]||link[2];
  value=value.replace(/^["']|["']$/g,'');
  if(/^file:\/\//i.test(value))value=fileURLToPath(value);
  if(/^[a-z]+:\/\//i.test(value))throw new Error('只接受本地安装包，不下载远程文件。');
  const resolved=path.resolve(cwd,value);
  if(!/\.tgz$/i.test(resolved)||!fs.statSync(resolved).isFile())throw new Error('请选择存在的本地 .tgz 文件。');
  return resolved;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try{console.log(resolvePackage(process.argv[2]));}catch(e){console.error(e.message);process.exitCode=1;}
}
