/** Conservative local intent recognizer. Quoted examples, questions and negation are not commands. */
export function memoryIntent(input) {
  if (typeof input !== 'string') return null;
  const raw=input.trim();
  if (/^\/memory\s+project(?:\s|$)/i.test(raw)) {
    const title=raw.replace(/^\/memory\s+project\s*/i,'').replace(/^["“]|["”]$/g,'').trim();
    return {kind:'save',suggestedName:title&&title!=='记忆名称'?title:''};
  }
  const politeQuestion=/^(?:请问[，,\s]*)?(?:可以|能不能|能否)帮我(?:记住|记下|保存|存一下)/u.test(raw);
  if (raw.length>600 || /```|^[>"“「]|(?:怎么|如何|为什么|是否|什么叫|例如|示例|测试句|他说|她说|翻译|解释|识别|匹配|按钮|功能|插件|正则)/u.test(raw)||(/[？?]|能否/u.test(raw)&&!politeQuestion)) return null;
  if (/(?:不要|不用|别|不必|无需|暂不|取消|停止|不想|不需要|不打算|没有让你|不要求)\s*(?:(?:帮我|替我|再|自动|继续|进行)\s*)*(?:记住|记下|记忆|存|保存|归档)/u.test(raw)) return null;
  const s=raw.normalize('NFKC').replace(/记柱/g,'记住').replace(/保存下/g,'保存一下').replace(/\s+/g,' ').trim();
  const verb=/^(?:(?:请|麻烦|劳驾|现在|先|也|再|帮我|替我|给我|请你|请帮我|麻烦你|能不能帮我|可以帮我|能否帮我|帮忙)[，,\s]*)*(?:(?:把|将)(?:这段|本次|当前|刚才|以上|上面|我们刚才|这次).{0,24}?(?:记住|记下来|保存|存下来|存一下|记一下)|(?:记住|记下|记一下|记下来|记一记|保存|存一下|存下|存下来|留存)(?:这|当前|本次|刚才|以上|上面|一下|下|我们|我|以后|本项目|项目|：|:|，|,|\s|$))/u;
  if (!verb.test(s)) return null;
  if (/(?:文件到|文件为|图片到|图片为|网页到|代码到|代码为|密码|密钥|口令|账号密码)/u.test(s)) return null;
  if (/(?:保存|存一下|存下)/u.test(s)&&/(?:文件|图片|表格|代码)/u.test(s)&&!/(?:对话|记忆|要点|结论|内容|讨论)/u.test(s))return null;
  return {kind:'save',suggestedName:''};
}
export const memoryTemplate='/memory project "记忆名称"';
export function intentPayload(text) {
  const explicit=/(?:记住|记下|记一下)\s*[:：，,]\s*(.+)$/su.exec(text);
  if(explicit)return explicit[1];
  return /(?:记住|记下|记一下)((?:以后|我们|我|本项目|项目).+)$/su.exec(text)?.[1]||'';
}
