/** Extractive only: every point is a verbatim source substring, never generated prose. */
export function categoryOf(s) {
  if (/(?:决定|确定|采用|选择|方案|定为)/u.test(s)) return 'decision';
  if (/(?:待办|下一步|需要完成|明天|负责|截止|TODO|todo)/u.test(s)) return 'todo';
  if (/(?:必须|禁止|不得|不能|约束|仅限)/u.test(s)) return 'constraint';
  if (/(?:偏好|喜欢|习惯|默认|以后|一直|prefer)/iu.test(s)) return 'preference';
  if (/(?:结论|结果|因此|综上)/u.test(s)) return 'conclusion';
  if (/\d/u.test(s)) return 'data';
  return 'fact';
}
export function extractPoints(text, source, max=Infinity) {
  if(typeof text!=='string')return [];
  const rows=[];
  for(const match of text.matchAll(/[^\n。！？!?]+[。！？!?]?/gu)) {
    const value=match[0].trim();
    // Link-only lines belong to the attachment checklist, not semantic key points.
    if(!value.replace(/!?\[[^\]]*\]\((?:<[^>]+>|[^)]+)\)/gu,'').trim())continue;
    if(value.length<5 || value.length>1500 || /^(?:好的|谢谢|收到|你好)[。！!]?$/u.test(value))continue;
    rows.push({id:`${source.seq}:${source.role}:${match.index}`,text:value,category:categoryOf(value),source});
    if(rows.length>=max)break;
  }
  return rows;
}
/** Candidate points one draft keeps; the local store accepts records up to this size. */
export const CANDIDATE_LIMIT=500;
export function mergePoints(previous,added,max=CANDIDATE_LIMIT) {
  const unique=new Map(previous.map(r=>[r.text,r]));
  for(const row of added)unique.set(row.text,row);
  const all=[...unique.values()];
  return {points:all.slice(-max),omitted:Math.max(0,all.length-max)};
}
export function titleSuggestion(points) {
  const row=[...points].reverse().find(p=>['decision','conclusion','todo'].includes(p.category))||points.at(-1);
  return row?row.text.slice(0,28):'对话记忆';
}

