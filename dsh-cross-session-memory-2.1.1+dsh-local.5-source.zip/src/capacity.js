/** Authoritative accounting only. Never pass a heuristic as a measured percentage. */
export function capacity(usage,window,revision) {
  const valid=x=>Number.isSafeInteger(x)&&x>=0;
  if(!valid(window)||window===0||!usage||!valid(usage.totalTokens))return {status:'unavailable',reason:'当前模型尚未提供可核验的总 token 数或上下文窗口。',revision};
  const used=usage.totalTokens;
  if(!valid(usage.inputTokens)||!valid(usage.outputTokens))return {status:'unavailable',reason:'用量字段异常。',revision};
  if(!valid(usage.cacheReadTokens??0)||!valid(usage.cacheWriteTokens??0))return {status:'unavailable',reason:'缓存用量字段异常。',revision};
  const sum=usage.inputTokens+usage.outputTokens+(usage.cacheReadTokens??0)+(usage.cacheWriteTokens??0);
  if(!Number.isSafeInteger(sum)||sum!==used)return {status:'unavailable',reason:'用量字段相互矛盾，未触发提醒。',revision};
  return {status:'measured',used,total:window,percent:Math.round(used/window*100),above70:BigInt(used)*100n>=BigInt(window)*70n,revision,
    reason:'模型返回的本次请求输入（含缓存）+输出 token 数 / 当前模型窗口；显示四舍五入到 1%。'};
}
export const unknownCapacity=()=>({status:'unavailable',reason:'等待模型返回实际用量。',revision:0});
