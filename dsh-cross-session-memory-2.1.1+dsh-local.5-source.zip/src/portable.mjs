// Shared verbatim between Codex and DSH. Local, self-contained exchange; no URL fetching.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
export const FORMAT='local-conversation-memory';
export const MAX_FILE=192*1024*1024;
const sha=b=>createHash('sha256').update(b).digest('hex');
const text=(s,max)=>typeof s==='string'&&s.length<=max;
const invalid=()=>{throw Error('通用记忆格式无效或超过容量限制；未导入。');};
export function validatePortable(doc) {
  if(!doc||doc.format!==FORMAT||doc.version!==1)throw Error('不支持的通用记忆格式/版本，请使用两端支持的 .memory.json 文件。');
  if(!text(doc.id,200)||!doc.id||!text(doc.name,100)||!doc.name.trim()||!Number.isFinite(Date.parse(doc.createdAt))||!doc.origin||!['codex','dsh'].includes(doc.origin.app)||!text(doc.origin.session,300)||!text(doc.origin.project,4096))invalid();
  if(!Array.isArray(doc.points)||doc.points.length>250||!Array.isArray(doc.sources)||!Array.isArray(doc.attachments)||doc.attachments.length>2000)invalid();
  const ids=new Set();
  for(const p of doc.points){if(!p||!text(p.id,500)||ids.has(p.id)||!text(p.text,1500)||!text(p.category,100)||!Number.isSafeInteger(p.source?.seq)||p.source.seq<0||!['user','assistant'].includes(p.source.role))invalid();ids.add(p.id);}
  let chars=0;for(const s of doc.sources){if(!s||!Number.isSafeInteger(s.seq)||!['user','assistant'].includes(s.role)||!text(s.text,32*1024*1024))invalid();chars+=Buffer.byteLength(s.text);if(chars>32*1024*1024)invalid();}
  let total=0;
  for(const a of doc.attachments){
    if(!a||!text(a.name,500)||!a.name||!Number.isSafeInteger(a.bytes)||a.bytes<0||a.bytes>50*1024*1024||!text(a.sha256,64)||!/^[a-f0-9]{64}$/.test(a.sha256)||typeof a.base64!=='string'||a.base64.length!==4*Math.ceil(a.bytes/3))invalid();
    total+=a.bytes;if(total>100*1024*1024)invalid();const bytes=Buffer.from(a.base64,'base64');
    if(bytes.length!==a.bytes||bytes.toString('base64')!==a.base64||sha(bytes)!==a.sha256)throw Error(`附件完整性校验失败：${a.name}`);
  }
  if(doc.extraction!==undefined&&(!doc.extraction||!Number.isSafeInteger(doc.extraction.omitted??0)||(doc.extraction.omitted??0)<0))invalid();
  // Normalize known fields; do not interpret paths, commands, or unknown instruction fields.
  return {format:FORMAT,version:1,id:doc.id,name:doc.name,createdAt:doc.createdAt,origin:{app:doc.origin.app,session:doc.origin.session,project:doc.origin.project},points:doc.points.map(p=>({id:p.id,text:p.text,category:p.category,source:{seq:p.source.seq,role:p.source.role}})),sources:doc.sources.map(s=>({seq:s.seq,role:s.role,text:s.text,...(typeof s.timestamp==='string'?{timestamp:s.timestamp}:{})})),attachments:doc.attachments.map(a=>({name:a.name,bytes:a.bytes,sha256:a.sha256,base64:a.base64})),extraction:doc.extraction||{method:'verbatim',omitted:0}};
}
export function readPortable(file) {
  if(!file||/^https?:|^\\\\|^\/\//i.test(file))throw Error('仅支持用户指定的本地记忆文件。');
  const fd=fs.openSync(file,'r');try{const s=fs.fstatSync(fd);if(!s.isFile()||s.size>MAX_FILE)invalid();return validatePortable(JSON.parse(fs.readFileSync(fd,'utf8').replace(/^\uFEFF/,'')));}finally{fs.closeSync(fd);}
}
export function makePortable(record,app,attachments) {
  const encoded=attachments.map(a=>{
    const fd=fs.openSync(a.path,'r');let bytes;
    try{const s=fs.fstatSync(fd);if(!s.isFile()||s.size>50*1024*1024)invalid();bytes=fs.readFileSync(fd);if(bytes.length!==s.size)invalid();}finally{fs.closeSync(fd);}
    if(a.sha256&&sha(bytes)!==a.sha256)throw Error(`本地附件已改变：${a.name}`);
    return {name:a.name,bytes:bytes.length,sha256:sha(bytes),base64:bytes.toString('base64')};
  });
  return validatePortable({format:FORMAT,version:1,id:record.portableId||record.id,name:record.name,createdAt:record.originCreatedAt||record.createdAt,origin:record.origin||{app,session:record.sourceSession,project:String(record.project)},points:record.points||[],sources:record.sources||[],attachments:encoded,extraction:record.extraction||{method:'verbatim',omitted:record.omitted||0}});
}
export function writePortable(file,doc) {
  const serialized=JSON.stringify(validatePortable(doc));if(Buffer.byteLength(serialized)>MAX_FILE)invalid();
  // Exclusive creation prevents replacing any existing memory or unrelated file.
  fs.writeFileSync(file,serialized,{flag:'wx',mode:0o600});return file;
}
export function importDraft(doc,{session,project}) {
  doc=validatePortable(doc);
  return {schema:1,session,project,points:doc.points,messages:doc.sources,resources:doc.attachments.map((a,i)=>({id:`portable:${i}`,name:a.name,bytes:a.bytes,available:true,path:'包含在通用记忆文件中'})),omitted:doc.extraction.omitted||0,suggestedName:doc.name,importName:doc.name,capacity:{status:'unknown',reason:'导入的是已有记忆，不使用原对话的容量数据。'},portable:doc};
}
export function selectPortable(doc,selection) {
  doc=validatePortable(doc);const name=selection.name?.trim();
  if(selection.confirmed!==true||!text(name,100)||!name||/[\x00-\x1f]/.test(name))throw Error('请在命名页面填写名称并确认导入。');
  if(!Array.isArray(selection.pointIds)||!Array.isArray(selection.resourceIds)||selection.pointIds.some(id=>!doc.points.some(p=>p.id===id))||selection.resourceIds.some(id=>!doc.attachments.some((_,i)=>`portable:${i}`===id)))invalid();
  const points=doc.points.filter(p=>selection.pointIds.includes(p.id)),seq=new Set(points.map(p=>p.source.seq));
  const attachments=doc.attachments.filter((_,i)=>selection.resourceIds.includes(`portable:${i}`));
  if(!points.length&&!attachments.length)throw Error('至少保留一个要点或附件。');
  return {...doc,name,points,sources:doc.sources.filter(s=>seq.has(s.seq)),attachments};
}
export function materialize(doc,dir) {
  fs.mkdirSync(dir,{recursive:true});
  return doc.attachments.map((a,i)=>{
    const leaf=`${i+1}-${a.name.replace(/[^\p{L}\p{N}._ -]/gu,'_').slice(0,100)}`;
    const target=path.join(dir,leaf);fs.writeFileSync(target,Buffer.from(a.base64,'base64'),{flag:'wx',mode:0o600});
    return {name:a.name,path:target,bytes:a.bytes,sha256:a.sha256};
  });
}
