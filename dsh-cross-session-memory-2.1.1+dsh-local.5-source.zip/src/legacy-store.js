import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { createHash, randomUUID } from 'node:crypto';

export const categories = ['decision', 'preference', 'fact', 'todo', 'constraint'];
const states = ['active', 'archived', 'pending'];
const digest = s => createHash('sha256').update(s).digest('hex');
const norm = s => s.normalize('NFKC').toLowerCase().replace(/\s+/gu, ' ').trim();
const DAY = 86400000;
export function configuration(raw = {}) {
  const c = {topK: 5, maxContextBytes: 6000, maxEntries: 1000, archiveDays: 30,
    autoArchive: true, autoSaveCategories: [], analyzeEvery: 1, ...raw};
  for (const [k, min, max] of [['topK',1,50],['maxContextBytes',512,20000],['maxEntries',1,10000],['archiveDays',1,36500],['analyzeEvery',1,1000]]) {
    if (!Number.isInteger(c[k]) || c[k] < min || c[k] > max) throw new Error(`配置 ${k} 应为 ${min}–${max} 的整数`);
  }
  if (typeof c.autoArchive !== 'boolean' || !Array.isArray(c.autoSaveCategories) || c.autoSaveCategories.some(x => !categories.includes(x))) throw new Error('自动保存/归档配置无效');
  if (c.storageDir !== undefined && (typeof c.storageDir !== 'string' || !path.isAbsolute(c.storageDir))) throw new Error('storageDir 必须是绝对路径');
  return c;
}
export function assertNotSensitive(value) {
  const s = JSON.stringify(value);
  const patterns = [
    /(?:password|passwd|pwd|api[_ -]?key|access[_ -]?token|secret|密码|口令|密钥|令牌)\s*["']?\s*[:=：]\s*["']?[^\s,"'}]{3,}/iu,
    /(?:密码|口令|密钥|令牌)(?:是|为|设为|设置为)\s*\S{3,}/u,
    /\b(?:sk|pk|ghp|github_pat|xox[baprs])[-_][A-Za-z0-9_-]{12,}/u,
    /-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----/u,
    /\bBearer\s+[A-Za-z0-9._~+\/-]{12,}/iu,
    /(?<!\d)\d{17}[\dXx](?!\d)/u,
    /\bAKIA[0-9A-Z]{16}\b/u,
    /\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/u,
  ];
  if (patterns.some(p => p.test(s))) throw new Error('检测到疑似密码、密钥、令牌或身份证号，已拒绝保存；请先去除敏感内容。');
}
export function projectFor(session) {
  if (!session?.id) throw new Error('缺少当前会话身份，记忆功能已跳过');
  const cwd = session.header?.cwd;
  if (!cwd || !path.isAbsolute(cwd)) throw new Error('当前会话没有绝对工作目录，请在项目会话中使用记忆功能');
  let canonical = fs.realpathSync.native(cwd);
  if (process.platform === 'win32') canonical = canonical.toLowerCase();
  // Home is available in restricted Windows hosts where uv_os_get_passwd may fail.
  // Isolation is per OS home/profile, not per remote Web UI login.
  const user = digest(path.resolve(os.homedir()));
  return {id: digest(`${user}\0${canonical}`), user, cwd: canonical, sourceSession: String(session.id)};
}
function tokens(s) {
  const v = norm(s), set = new Set(v.match(/[a-z0-9_]+/g) || []);
  for (const run of v.match(/[\p{Script=Han}]+/gu) || []) {
    if (run.length === 1) set.add(run);
    for (let i = 0; i < run.length - 1; i++) set.add(run.slice(i,i+2));
  }
  return set;
}
function similarity(a,b) {
  const aa = tokens(a), bb = tokens(b);
  if (!aa.size || !bb.size) return 0;
  return [...aa].filter(x => bb.has(x)).length / Math.sqrt(aa.size * bb.size);
}
export class MemoryStore {
  constructor(config = {}) {
    this.config = configuration(config);
    const home = process.env.DSH_HOME?.trim() || path.join(os.homedir(), '.dsh');
    this.root = this.config.storageDir || path.join(path.resolve(home), 'cross-session-memory');
  }
  location(project) { return path.join(this.root, project.user, `${project.id}.json`); }
  read(project) {
    const file = this.location(project);
    let db;
    try {
      if (fs.statSync(file).size > 64 * 1024 * 1024) throw new Error('记忆文件超过安全读取上限');
      db = JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (e) {
      if (e.code === 'ENOENT') return {version:1, project:project.id, user:project.user, entries:[], audit:[]};
      throw new Error('记忆文件无法读取；原文件未覆盖，请检查权限或文件内容');
    }
    if (db.version !== 1 || db.project !== project.id || db.user !== project.user || !Array.isArray(db.entries) || !Array.isArray(db.audit)) throw new Error('记忆文件格式或所属项目不匹配');
    const ids = new Set();
    for (const r of db.entries) {
      if (!r || typeof r.id !== 'string' || ids.has(r.id) || !states.includes(r.status) || !categories.includes(r.category)
        || typeof r.summary !== 'string' || typeof r.context !== 'string' || typeof r.key !== 'string' || !Array.isArray(r.tags)
        || r.tags.some(t => typeof t !== 'string') || typeof r.sourceSession !== 'string' || !Number.isFinite(r.importance)
        || !Array.isArray(r.conflicts) || r.conflicts.some(id => typeof id !== 'string') || typeof r.pinned !== 'boolean' || r.project !== project.id
        || ['createdAt','updatedAt','lastAccessedAt'].some(k => !Number.isFinite(Date.parse(r[k])))) throw new Error('记忆条目损坏，已停止读取和写入');
      ids.add(r.id);
    }
    return db;
  }
  transaction(project, fn) {
    const file = this.location(project), lock = `${file}.lock`;
    fs.mkdirSync(path.dirname(file), {recursive:true, mode:0o700});
    let handle;
    try { handle = fs.openSync(lock, 'wx', 0o600); } catch { throw new Error('记忆存储正被其他进程使用或不可写，请稍后重试；异常退出残留锁请按说明处理'); }
    let temporary;
    try {
      const db = this.read(project), result = fn(db);
      temporary = `${file}.${randomUUID()}.tmp`;
      const fd = fs.openSync(temporary, 'wx', 0o600);
      try { const serialized=JSON.stringify(db,null,2); if(Buffer.byteLength(serialized)>64*1024*1024)throw new Error('记忆库达到 64 MiB 上限，请清理后重试'); fs.writeFileSync(fd, serialized, 'utf8'); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      fs.renameSync(temporary, file);
      return result;
    } finally {
      if (temporary && fs.existsSync(temporary)) fs.unlinkSync(temporary);
      fs.closeSync(handle); fs.unlinkSync(lock);
    }
  }
  log(db, action, ids, project) {
    db.audit.push({at:new Date().toISOString(), action, ids, sourceSession:project.sourceSession});
    db.audit = db.audit.slice(-1000);
  }
  maintain(project) {
    if (!this.config.autoArchive) return;
    const cutoff = Date.now() - this.config.archiveDays * DAY;
    if (!this.read(project).entries.some(r => r.status === 'active' && !r.pinned && Date.parse(r.lastAccessedAt) < cutoff)) return;
    this.transaction(project, db => {
      const changed = [];
      for (const r of db.entries) if (r.status === 'active' && !r.pinned && Date.parse(r.lastAccessedAt) < cutoff) {
        r.status = 'archived'; r.updatedAt = new Date().toISOString(); changed.push(r.id);
      }
      this.log(db, 'auto-archive', changed, project);
    });
  }
  manage(project, args) {


    if (args.action === 'status') {
      const db = this.read(project);
      return {ok:true, project:project.cwd, file:this.location(project), count:db.entries.length, maxEntries:this.config.maxEntries, archiveDays:this.config.archiveDays, autoSaveCategories:this.config.autoSaveCategories};
    }
    if (args.action === 'list') {
      const offset = args.offset ?? 0;
      if (!Number.isInteger(offset) || offset < 0) throw new Error('offset 必须是非负整数');
      if (args.status && !states.includes(args.status)) throw new Error('未知状态');
      const rows = this.read(project).entries.filter(r => (!args.status || r.status === args.status) && (!args.query || norm(JSON.stringify(r)).includes(norm(args.query))));
      return {ok:true,total:rows.length,entries:rows.slice(offset,offset+20),nextOffset:offset+20<rows.length?offset+20:null};
    }
    if (args.action === 'export') {
      const db = this.read(project), dir = path.join(this.root, project.user, 'exports');
      fs.mkdirSync(dir,{recursive:true,mode:0o700});
      const file = path.join(dir,`${project.id}-${Date.now()}-${randomUUID().slice(0,8)}.json`);
      fs.writeFileSync(file,JSON.stringify(db,null,2),{encoding:'utf8',mode:0o600,flag:'wx'});
      return {ok:true,file,count:db.entries.length};
    }
    return this.transaction(project, db => {
      if (args.action === 'clear') { const ids = db.entries.map(r=>r.id); db.entries=[]; this.log(db,'clear',ids,project); return {ok:true,deleted:ids.length}; }
      const row = db.entries.find(r=>r.id === args.id);
      if (!row) throw new Error('当前项目中没有该记忆 ID');
      if (args.action === 'delete') db.entries = db.entries.filter(r=>r.id !== row.id);
      else if (args.action === 'archive') row.status = 'archived';
      else if (args.action === 'restore') {
        if (row.status !== 'archived') throw new Error('仅能恢复已归档条目');
        const conflicts = db.entries.filter(r=>r.id!==row.id && r.status==='active' && ((row.key && r.key===row.key) || (row.category===r.category && similarity(row.summary,r.summary)>=0.65))).map(r=>r.id);
        row.conflicts=conflicts; row.status=conflicts.length?'pending':'active'; row.lastAccessedAt=new Date().toISOString();
      } else if (args.action === 'resolve') {
        if (row.status !== 'pending') throw new Error('仅能处理待确认冲突');
        if (!['keep_old','use_new'].includes(args.resolution)) throw new Error('resolution 应为 keep_old 或 use_new');
        if (args.resolution === 'keep_old') row.status='archived';
        else {
          // Recompute same-key conflicts so concurrent candidates cannot leave two active values.
          for (const old of db.entries) if (old.id !== row.id && old.status === 'active' && (row.conflicts.includes(old.id) || (row.key && old.key === row.key))) {
            old.status='archived'; old.updatedAt=new Date().toISOString();
          }
          row.status='active'; row.lastAccessedAt=new Date().toISOString();
        }
      } else throw new Error('未知管理操作');
      row.updatedAt=new Date().toISOString(); this.log(db,args.action,[row.id],project);
      return {ok:true,action:args.action,entry:args.action==='delete'?null:row};
    });
  }
}

