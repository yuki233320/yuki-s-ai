import {z} from 'zod';
import {memoryIntent,intentPayload} from './intent.js';
import {extractPoints,mergePoints,titleSuggestion} from './extract.js';
import {resourcesFrom,mergeResources} from './resources.js';
import {capacity,unknownCapacity} from './capacity.js';

const point=z.object({id:z.string(),text:z.string().max(1500),category:z.string(),source:z.object({seq:z.number(),role:z.string()})});
const resource=z.object({id:z.string(),kind:z.enum(['file','image','path']),name:z.string(),seq:z.number(),path:z.string().optional(),ref:z.record(z.string(),z.unknown()).optional()});
const recovery=z.object({id:z.string(),message:z.string(),failures:z.array(z.object({kind:z.enum(['point','resource']),id:z.string(),name:z.string(),reason:z.string()}))});
const draft=z.object({id:z.string(),named:z.boolean().optional(),suggestedName:z.string(),points:z.array(point),resources:z.array(resource),omitted:z.number(),imported:z.boolean().optional(),recovery:recovery.optional()});
const monitor=z.object({status:z.enum(['unavailable','measured','stale']),reason:z.string(),revision:z.number(),used:z.number().optional(),total:z.number().optional(),percent:z.number().optional(),above70:z.boolean().optional()});
const saved=z.object({id:z.string(),name:z.string(),points:z.number(),resources:z.number(),file:z.string(),portablePath:z.string().nullable(),portableTrimmed:z.number()});
const schema=z.object({sessionId:z.string(),inherited:z.number(),points:z.array(point),resources:z.array(resource),omitted:z.number(),draft:draft.nullable(),lastSaved:saved.nullable(),window:z.number().nullable(),monitor,
  running:z.boolean(),reminder:z.boolean(),suppressed:z.boolean(),reminded:z.boolean(),notice:z.string(),pending:z.record(z.string(),z.string())});
/** `named` records that the name came from the user: only then does the panel prefill the field. */
function openDraft(s,id,name='') {const given=typeof name==='string'&&name.trim();return {...s,draft:{id,named:!!given,suggestedName:given?name.trim().slice(0,100):titleSuggestion(s.points),points:s.points,resources:s.resources,omitted:s.omitted},notice:''};}
export function parseUI(raw) {try {const v=JSON.parse(raw.trim());return v&&typeof v==='object'?v:null;}catch{return null;}}
export function fold(s,e) {
  const d=e.data||{};
  // A fork may use inherited facts, but must not inherit another conversation's open UI or dismissals.
  const live=e.seq>=s.inherited;
  if(e.type==='memory/portable-import'&&live)return {...s,draft:d.draft,notice:'请核对导入记忆的名称、要点与附件，然后确认。'};
  if(e.type==='memory/selection-failed'&&live&&s.draft?.id===d.draftId){
    const checked=recovery.safeParse(d);if(!checked.success)return s;
    const valid=checked.data.failures.filter(f=>(f.kind==='point'?s.draft.points:s.draft.resources).some(item=>item.id===f.id));
    return {...s,draft:{...s.draft,recovery:{...checked.data,failures:valid}},notice:checked.data.message};
  }
  if(e.type==='memory/saved'&&live)return {...s,lastSaved:{id:String(d.id),name:String(d.name),points:Number.isFinite(d.points)?d.points:0,resources:Number.isFinite(d.resources)?d.resources:0,file:String(d.file),portablePath:typeof d.portablePath==='string'?d.portablePath:null,portableTrimmed:Number.isFinite(d.portableTrimmed)?d.portableTrimmed:0}};
  if(e.type==='request/context')return {...s,window:Number.isSafeInteger(d.contextWindow)?d.contextWindow:null,monitor:{...s.monitor,status:'stale',reason:'模型路由已更新，等待新用量。'}};
  if(e.type==='turn/start')return {...s,running:true,reminder:false,monitor:{...s.monitor,status:'stale',reason:'本轮正在处理；上次用量不是当前精确值。'}};
  if(e.type==='tool/result'||e.type==='system/message'||e.type==='developer/message')return {...s,monitor:{...s.monitor,status:'stale',reason:'上下文发生变化，等待模型回报。'}};
  if(e.type==='user/message'||e.type==='assistant/message') {
    const m=e.type==='user/message'?d:d.message;
    if(!m)return s;
    const text=(m.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('\n');
    const intent=e.type==='user/message'&&m.source?.kind==='user'?memoryIntent(text):null;
    let points=s.points,omitted=s.omitted;
    // Exclude plugin context, reasoning, tool results, and the save request itself.
    if(!intent&&(e.type==='assistant/message'||m.source?.kind==='user')) {
      const merged=mergePoints(points,extractPoints(text,{seq:e.seq,role:m.role||'user'}));points=merged.points;omitted+=merged.omitted;
    }
    if(intent&&intentPayload(text)) {const merged=mergePoints(points,extractPoints(intentPayload(text),{seq:e.seq,role:'user'}));points=merged.points;omitted+=merged.omitted;}
    const resources=e.type==='assistant/message'||m.source?.kind==='user'?mergeResources(s.resources,resourcesFrom(m.content,e.seq)):s.resources;
    let next={...s,points,omitted,resources,monitor:e.type==='assistant/message'?capacity(d.usage,s.window,e.seq):{...s.monitor,status:'stale',reason:'用户输入已变化，等待新用量。'}};
    if(intent&&live)next=openDraft(next,`${s.sessionId}:${e.seq}`,intent.suggestedName);
    return next;
  }
  if(e.type==='turn/end') {
    const show=live&&!s.suppressed&&!s.reminded&&s.monitor.status==='measured'&&s.monitor.above70===true&&d.reason?.kind==='completed';
    return {...s,running:false,reminder:show||s.reminder,reminded:s.reminded||show};
  }
  if(e.type==='command/run'&&live) {
    if(d.name==='memory')return /^\s*project(?:\s|$)/i.test(d.args||'')?openDraft(s,`${s.sessionId}:${e.seq}`,(d.args||'').replace(/^\s*project\s*/i,'').replace(/^["“]|["”]$/g,'').replace(/^记忆名称$/,'').trim()):s;
    if(d.name==='memory-ui') {
      const input=parseUI(d.args||'');if(!input)return s;
      if(input.action==='open'||input.action==='refresh')return openDraft(s,`${s.sessionId}:${e.seq}`,input.name||'');
      return typeof input.action==='string'?{...s,pending:{...s.pending,[d.commandId]:input.action}}:s;
    }
  }
  if(e.type==='command/done'&&s.pending[d.commandId]) {
    const action=s.pending[d.commandId],pending={...s.pending};delete pending[d.commandId];
    if(d.kind!=='success')return {...s,pending,notice:d.text||'操作失败，请重试。'};
    if(action==='cancel')return {...s,pending,draft:null,notice:''};
    if(action==='dismiss')return {...s,pending,reminder:false,suppressed:true,notice:'本对话不再提醒。'};
    if(action==='commit')return {...s,pending,draft:null,reminder:false,suppressed:true,notice:''};
    return {...s,pending,notice:d.text||''};
  }
  return s;
}
export const projection={key:'crossSessionMemory',stateVersion:3,stateSchema:schema,
  init:(header,inherited=0)=>({sessionId:String(header.id),inherited,points:[],resources:[],omitted:0,draft:null,lastSaved:null,window:null,monitor:unknownCapacity(),running:false,reminder:false,suppressed:false,reminded:false,notice:'',pending:{}}),
  apply:fold,wire:{viewSchema:schema,view:s=>s}};
