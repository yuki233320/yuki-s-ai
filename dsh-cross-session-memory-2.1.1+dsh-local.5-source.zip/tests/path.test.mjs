import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import {pathToFileURL} from 'node:url';
import {resolvePackage} from '../scripts/resolve-path.mjs';
test('absolute, relative, quoted, markdown, file URL and spaced install paths',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dsh-path-')),file=path.join(dir,'记忆 插件.tgz');fs.writeFileSync(file,'test');
  for(const p of [file,'"'+file+'"',`[安装包](<${file}>)`,pathToFileURL(file).href])assert.equal(resolvePackage(p),file);
  assert.equal(resolvePackage('记忆 插件.tgz',dir),file);assert.throws(()=>resolvePackage('https://example.com/plugin.tgz'));
});
