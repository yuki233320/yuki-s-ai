﻿$ErrorActionPreference = 'Stop'
$taskFixture = Join-Path ([IO.Path]::GetTempPath()) ('dsh-install-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $taskFixture | Out-Null
$taskPackage = Join-Path $taskFixture '记忆 插件.tgz'
Set-Content -LiteralPath $taskPackage -Value 'synthetic path fixture'
function global:InvokeMemoryTestDsh { $global:MemoryTestArguments = @($args); $global:LASTEXITCODE = 0 }
try {
    Push-Location $taskFixture
    $taskForms = @($taskPackage, '记忆 插件.tgz', ('"' + $taskPackage + '"'), ('[安装包](<' + $taskPackage + '>)'), ([uri]$taskPackage).AbsoluteUri)
    foreach ($taskForm in $taskForms) {
        & (Join-Path $PSScriptRoot '../scripts/install.ps1') -PackagePath $taskForm -Profile web -DshCommand InvokeMemoryTestDsh
        $taskExpected = @('plugin', '--profile', 'web', 'add', $taskPackage)
        if (($global:MemoryTestArguments | ConvertTo-Json -Compress) -ne ($taskExpected | ConvertTo-Json -Compress)) { throw '路径未作为完整的单个参数传递' }
    }
    Write-Output 'PASS PowerShell install wrapper: 5 path forms, single literal argument, no real installation invoked.'
} finally {
    Pop-Location
    Remove-Item Function:\InvokeMemoryTestDsh
    Remove-Variable MemoryTestArguments -Scope Global -ErrorAction SilentlyContinue
}
