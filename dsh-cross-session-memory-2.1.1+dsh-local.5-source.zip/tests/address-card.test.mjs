// Local revision 2.1.1+dsh-local.3: a save result becomes a structured event and a
// hover-only address card, instead of a permanent line under the composer.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import * as host from '../lib/index.js';
import { projection, fold } from '../lib/projection.js';

const point = { id:'p1', text:'本次对话约定：保存结果不再常驻输入区，改由悬停卡片承载', category:'decision', source:{ seq:3, role:'user' } };

function harness() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-address-'));
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-cwd-'));
  const commands = new Map(), tools = new Map(), appended = [];
  const draft = { id:'draft-1', suggestedName:'地址测试', points:[point], resources:[], omitted:0 };
  const ctx = {
    sessionProjections: { register() {}, stateOf: () => ({ draft }) },
    commands: { register(spec) { commands.set(spec.name, spec); } },
    tools: { register(spec) { tools.set(spec.name, spec); } },
    systemPrompt: { section() {}, variable() {}, context() {} },
    on() {},
    get() { return undefined; },
  };
  host.apply(ctx, { storageDir: root });
  const agent = { session: { id:`session-${randomUUID()}`, header:{ cwd }, append(type, data) { appended.push({ type, data }); } } };
  const signal = () => new AbortController().signal;
  return {
    root, appended,
    commit(extra = {}) {
      return commands.get('memory-ui').handler({ agent, signal:signal(),
        rawInput: JSON.stringify({ action:'commit', draftId:draft.id, name:'地址测试', pointIds:['p1'], resourceIds:[], ...extra }) });
    },
    tool(args) { return tools.get('cross_session_memory').execute(args, { agent, signal:signal() }); },
  };
}

test('a save reports a structured event and keeps every path out of the command text', async () => {
  const h = harness();
  const result = await h.commit();
  assert.equal(result.kind, 'success');
  assert.ok(!result.text.includes('位置：'), '命令文案不应再包含记忆库路径');
  assert.ok(!result.text.includes('跨端通用文件：'), '命令文案不应再包含通用文件路径');
  assert.ok(!/[A-Za-z]:\\/.test(result.text), '命令文案不应包含盘符路径');
  assert.ok(result.text.length < 80, '命令文案应当很短');

  const saved = h.appended.filter((e) => e.type === 'memory/saved');
  assert.equal(saved.length, 1, '必须发出一次 memory/saved');
  const data = saved[0].data;
  assert.equal(data.name, '地址测试');
  assert.equal(data.points, 1);
  assert.equal(data.resources, 0);
  assert.match(data.file, /\.json$/);
  assert.match(data.portablePath, /portable\.memory\.json$/);
  assert.equal(data.portableTrimmed, 0);
  assert.equal((await h.tool({ action:'list' })).total, 1, '记忆本身要照常入库');
});

test('the projection parks the save in lastSaved and clears the notice', () => {
  const state = projection.init({ id:'session-address' }, 0);
  const run = fold(state, { seq:5, type:'command/run', data:{ name:'memory-ui', args:JSON.stringify({ action:'commit' }), commandId:'c1' } });
  assert.equal(run.pending.c1, 'commit');
  const stored = fold(run, { seq:6, type:'memory/saved', data:{ id:'mem-1', name:'跨端记忆', points:276, resources:0, file:'C:\\store\\a.json', portablePath:'C:\\store\\assets\\x\\portable.memory.json', portableTrimmed:26 } });
  assert.deepEqual(stored.lastSaved, { id:'mem-1', name:'跨端记忆', points:276, resources:0, file:'C:\\store\\a.json', portablePath:'C:\\store\\assets\\x\\portable.memory.json', portableTrimmed:26 });
  const done = fold(stored, { seq:7, type:'command/done', data:{ commandId:'c1', kind:'success', text:'已保存“跨端记忆”：276 条原文要点、0 个本地文件。位置：C:\\store\\a.json' } });
  assert.equal(done.notice, '', '提交后不能再把结果贴到输入区');
  assert.equal(done.draft, null);
  assert.equal(done.lastSaved.points, 276, 'lastSaved 必须保留下来供卡片使用');
});

test('a memory saved without the exchange file still yields a usable card', () => {
  const state = projection.init({ id:'session-no-portable' }, 0);
  const stored = fold(state, { seq:4, type:'memory/saved', data:{ id:'mem-2', name:'仅本地', points:3, resources:1, file:'C:\\store\\b.json', portablePath:null, portableTrimmed:0 } });
  assert.equal(stored.lastSaved.portablePath, null, '未生成通用文件时卡片要能区分');
});

test('errors and import hints still surface through the notice', () => {
  const state = projection.init({ id:'session-error' }, 0);
  const run = fold(state, { seq:5, type:'command/run', data:{ name:'memory-ui', args:JSON.stringify({ action:'commit' }), commandId:'c1' } });
  const failed = fold(run, { seq:6, type:'command/done', data:{ commandId:'c1', kind:'error', text:'请输入 1–100 字符的记忆名称。' } });
  assert.match(failed.notice, /请输入 1–100 字符的记忆名称/);
  const imported = fold(state, { seq:8, type:'memory/portable-import', data:{ draft:{ id:'i1', suggestedName:'导入', points:[], resources:[], omitted:0, imported:true } } });
  assert.match(imported.notice, /请核对导入记忆的名称/);
});

test('the built host bundle no longer assembles the permanent long sentence', () => {
  const bundle = fs.readFileSync(new URL('../lib/index.js', import.meta.url), 'utf8');
  assert.ok(!bundle.includes('；跨端通用文件：'), '不应再拼接常驻长文案');
  assert.ok(bundle.includes('memory/saved'), '必须发出结构化事件');
});

test('the built client renders a hover-only address card', () => {
  const client = fs.readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8');
  assert.match(client, /address:'记忆地址'/);
  assert.match(client, /memoryFile:'记忆库文件'/);
  assert.match(client, /portableFile:'跨端通用文件'/);
  assert.match(client, /copyAddress:'复制地址'/);
  assert.match(client, /className:'address'/);
  assert.match(client, /className:'card'/);
  assert.match(client, /onMouseEnter:openAddress/);
  assert.match(client, /onMouseLeave:closeAddress/);
  assert.match(client, /copyAddress/);
  assert.match(client, /\.dsh-memory \.card\{position:fixed/);
  assert.match(client, /setTimeout\(\(\)=>setFlash\(''\),6000\)/, '瞬时确认必须自动消失');
  assert.match(client, /rotate\(-90 7 7\)/, '上一轮的原生环形进度不能被破坏');
  assert.match(client, /namePlaceholder:'请自定义命名该记忆'/);
  assert.match(client, /onMouseOver:holdAddress/, '指针进入卡片必须取消关闭');
  assert.match(client, /closeTimer\.current=setTimeout/, '离开只能延时关闭');
  assert.match(client, /closeAddressNow/, 'Esc 与真正失焦仍要立即关闭');
  assert.match(client, /\.dsh-memory \.card:hover\{background:var\(--dsw-alias-bg-layer-1/, '悬停时必须换成原生不透明底色');
});
