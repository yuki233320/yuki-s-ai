import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {memoryIntent} from '../src/intent.js';
import {extractPoints} from '../src/extract.js';
import {resourcesFrom} from '../src/resources.js';
import {capacity} from '../src/capacity.js';
import {projection,fold} from '../lib/projection.js';
import {NamedMemoryStore,projectFor} from '../src/store.js';
const corpus=JSON.parse(fs.readFileSync(new URL('./intent-corpus.json',import.meta.url)));
test('offline intent acceptance: positives and false-positive rate',()=>{
  const fn=corpus.positive.filter(s=>!memoryIntent(s)),fp=corpus.negative.filter(s=>memoryIntent(s));
  console.log(JSON.stringify({samples:corpus.positive.length+corpus.negative.length,positives:corpus.positive.length,negatives:corpus.negative.length,falsePositives:fp.length,falseNegatives:fn.length,falsePositiveRate:fp.length/corpus.negative.length,fn,fp}));
  assert.equal(fn.length,0);assert.ok(fp.length/corpus.negative.length<0.05);assert.equal(fp.length,0);
});
test('extractor produces exact original substrings with source roles',()=>{
  const source='我们决定采用 SQLite。下一步：周五完成验收。预算为 1200 元。不要上传数据。';
  const rows=extractPoints(source,{seq:3,role:'user'});assert.equal(rows.length,4);
  for(const row of rows)assert.ok(source.includes(row.text));assert.equal(rows[0].category,'decision');assert.equal(rows[1].source.seq,3);
});
test('resource discovery only includes explicit references, excludes web URLs',()=>{
  const rows=resourcesFrom([{type:'text',text:'[报告](<C:\\资料 空格\\报告.pdf>) [网站](https://example.com/a.pdf) ./test.txt'}, {type:'image',attachment:{attachmentId:'sha256:abc',bytes:3,name:'image.png'}}],5);
  assert.ok(rows.some(r=>r.path==='C:\\资料 空格\\报告.pdf'));assert.ok(rows.some(r=>r.path==='./test.txt'));assert.ok(rows.some(r=>r.kind==='image'));assert.ok(!rows.some(r=>r.path?.startsWith('https')));
});
test('exact capacity boundary and cache accounting',()=>{
  const usage=n=>({inputTokens:n-20,outputTokens:20,totalTokens:n});
  assert.equal(capacity(usage(699),1000,2).above70,false);assert.equal(capacity(usage(700),1000,2).above70,true);
  assert.equal(capacity(usage(696),1000,2).percent,70);assert.equal(capacity(usage(696),1000,2).above70,false);
  assert.equal(capacity({inputTokens:400,cacheReadTokens:200,outputTokens:100,totalTokens:700},1000,2).above70,true);
  assert.equal(capacity({inputTokens:500,outputTokens:100,totalTokens:700},1000,2).status,'unavailable');
  assert.equal(capacity(usage(700),null,2).status,'unavailable');assert.equal(capacity({},1000,2).status,'unavailable');
  for(const cacheReadTokens of [-1,NaN,Infinity,1.5,'1'])assert.equal(capacity({inputTokens:700,outputTokens:0,cacheReadTokens,totalTokens:700},1000,2).status,'unavailable');
});
function event(type,data,seq){return {type,data,seq,time:Date.now()};}
test('reminder appears only after completed answer; dismissal persists',()=>{
  let s=projection.init({id:'s'});s=fold(s,event('request/context',{contextWindow:1000},0));s=fold(s,event('turn/start',{},1));
  s=fold(s,event('assistant/message',{message:{role:'assistant',content:[{type:'text',text:'答案已经完成。'}]},usage:{inputTokens:650,outputTokens:50,totalTokens:700}},2));assert.equal(s.reminder,false);
  s=fold(s,event('turn/end',{reason:{kind:'completed'}},3));assert.equal(s.reminder,true);
  s=fold(s,event('command/run',{commandId:'c',name:'memory-ui',args:'{"action":"dismiss"}'},4));s=fold(s,event('command/done',{commandId:'c',kind:'success'},5));assert.equal(s.suppressed,true);assert.equal(s.reminder,false);
  s=fold(s,event('turn/end',{reason:{kind:'completed'}},6));assert.equal(s.reminder,false);
});
test('stale and interrupted measurements do not trigger',()=>{
  let s=projection.init({id:'s'});s={...s,window:1000};
  s=fold(s,event('assistant/message',{message:{content:[]},usage:{inputTokens:700,outputTokens:10,totalTokens:710}},1));s=fold(s,event('tool/result',{},2));s=fold(s,event('turn/end',{reason:{kind:'completed'}},3));assert.equal(s.reminder,false);
});
test('natural trigger opens one named draft, cancel does not save',()=>{
  let s=projection.init({id:'s'});s=fold(s,event('user/message',{role:'user',source:{kind:'user'},content:[{type:'text',text:'决定采用本地数据库。'}]},0));
  s=fold(s,event('user/message',{role:'user',source:{kind:'user'},content:[{type:'text',text:'帮我记一下'}]},1));assert.ok(s.draft);assert.ok(s.draft.suggestedName);assert.equal(s.draft.points.length,1);
  s=fold(s,event('command/run',{commandId:'c',name:'memory-ui',args:'{"action":"cancel"}'},2));s=fold(s,event('command/done',{commandId:'c',kind:'success'},3));assert.equal(s.draft,null);
});
test('fork does not reopen inherited request',()=>{
  let s=projection.init({id:'fork'},9);s=fold(s,event('user/message',{role:'user',source:{kind:'user'},content:[{type:'text',text:'记住这段对话'}]},2));assert.equal(s.draft,null);
});

test('injected historical context cannot become a new attachment or point',()=>{
  const s=projection.init({id:'s'});
  const next=fold(s,event('user/message',{role:'user',source:{kind:'runtime'},content:[{type:'text',text:'历史引用：[资料](C:/another-session/private.txt)'}]},0));
  assert.deepEqual(next.points,[]);assert.deepEqual(next.resources,[]);assert.equal(next.draft,null);
});

test('link-only rows are represented by the checklist rather than duplicate points',()=>{
  assert.equal(extractPoints('[文档](<C:/test/file.txt>) [图片](./a.png)',{seq:1,role:'user'}).length,0);
});

test('invalid UI payload cannot corrupt serializable projection state',()=>{
  let s=projection.init({id:'s'});
  for(const args of ['{"action":"open","name":12}','{"action":{"bad":true}}']){
    s=fold(s,event('command/run',{name:'memory-ui',commandId:'x',args},0));
    assert.equal(projection.stateSchema.safeParse(s).success,true);
  }
});
test('named snapshot: blank/forged selection rejected, selected files preserved locally',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dsh-memory-v2-')),file=path.join(dir,'资料 空格.txt');fs.writeFileSync(file,'这是一份合成测试附件。');
  const store=new NamedMemoryStore({storageDir:path.join(dir,'memory')}),project=projectFor({id:'s1',header:{cwd:dir}});
  const draft={id:'d1',points:[{id:'p',text:'决定采用 SQLite。',category:'decision',source:{seq:1,role:'user'}}],resources:[{id:'f',kind:'path',name:'资料 空格.txt',path:file,seq:1}],omitted:0};
  const args={draftId:'d1',name:'测试记忆',pointIds:['p'],resourceIds:['f']};
  await assert.rejects(()=>store.saveDraft(project,draft,{...args,name:''}),/名称/);
  await assert.rejects(()=>store.saveDraft(project,draft,{...args,resourceIds:['forged']}),/本次对话/);
  const result=await store.saveDraft(project,draft,args);assert.equal(result.resources,1);
  const r=store.read(project).entries[0];assert.equal(fs.readFileSync(r.resources[0].path,'utf8'),'这是一份合成测试附件。');
  assert.equal(store.context(project,'').length,0);const otherSession={...project,sourceSession:'s2'};assert.equal(store.context(otherSession,'English paraphrase')[0].name,'测试记忆');
  await assert.rejects(()=>store.saveDraft(project,draft,args),/同名/);
});
test('missing file fails without partial record, no file selection needs no file read',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dsh-memory-v2-'));const store=new NamedMemoryStore({storageDir:path.join(dir,'memory')}),p=projectFor({id:'s1',header:{cwd:dir}});
  const draft={id:'d',points:[{id:'p',text:'记忆测试内容。',category:'fact',source:{seq:1,role:'user'}}],resources:[{id:'f',kind:'path',name:'lost.txt',path:'lost.txt',seq:1}],omitted:0};
  const a={draftId:'d',name:'测试',pointIds:['p'],resourceIds:['f']};await assert.rejects(()=>store.saveDraft(p,draft,a),/无法读取/);assert.equal(store.read(p).entries.length,0);
  await store.saveDraft(p,draft,{...a,resourceIds:[]});assert.equal(store.read(p).entries.length,1);
});

test('corrupted named rows fail closed without replacing the original file',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dsh-corrupt-')),store=new NamedMemoryStore({storageDir:path.join(dir,'memory')}),p=projectFor({id:'s',header:{cwd:dir}});
  const draft={id:'d',points:[{id:'p',text:'采用本地存储。',category:'decision',source:{seq:1,role:'user'}}],resources:[],omitted:0};
  await store.saveDraft(p,draft,{draftId:'d',name:'测试',pointIds:['p'],resourceIds:[]});
  const db=store.read(p);db.entries[0].points=[null];const broken=JSON.stringify(db);fs.writeFileSync(store.location(p),broken);
  assert.throws(()=>store.context({...p,sourceSession:'other'}),/损坏/);assert.equal(fs.readFileSync(store.location(p),'utf8'),broken);
});
