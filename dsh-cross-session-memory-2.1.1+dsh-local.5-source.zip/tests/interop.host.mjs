import {Context} from '@deepseek-ai/cordis';
import Sessions from '@deepseek-ai/dsh-session';
import Projections from '@deepseek-ai/dsh-session-projection';
import SystemPrompt from '@deepseek-ai/dsh-system-prompt';
import Tools from '@deepseek-ai/dsh-tools';
import Commands from '@deepseek-ai/dsh-commands';
import * as plugin from '../lib/index.js';
import {writePortable} from '../src/portable.mjs';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import assert from 'node:assert/strict';
const root=await fs.mkdtemp(path.join(os.tmpdir(),'interop-host-'));
const ctx=new Context();
try{
 await ctx.plugin(Sessions);await ctx.plugin(Projections);await ctx.plugin(SystemPrompt);await ctx.plugin(Tools);await ctx.plugin(Commands);await ctx.plugin(plugin,{storageDir:path.join(root,'db')});
 const file=path.join(root,'跨端 文件.memory.json');writePortable(file,{format:'local-conversation-memory',version:1,id:randomUUID(),name:'Codex 导入',createdAt:new Date().toISOString(),origin:{app:'codex',project:'original',session:randomUUID()},points:Array.from({length:250},(_,i)=>({id:String(i),text:`原文决策 ${i}`,category:'decision',source:{seq:1,role:'user'}})),sources:[{seq:1,role:'user',text:'真实测试原文'}],attachments:[]});
 const session=ctx.sessions.create('dsh-import',{meta:{cwd:root}}),agent={id:'dsh-import',session};
 const run=s=>ctx.commands.execute(agent,s,[],new AbortController().signal);
 const staged=await run(`/memory-import "${file}"`);assert.equal(staged.result.kind,'success',JSON.stringify(staged));
 const draft=ctx.sessionProjections.stateOf(session,'crossSessionMemory').draft;assert.equal(draft.points.length,250);assert.equal(draft.imported,true);assert.equal(draft.suggestedName,'Codex 导入');
 const bad=await run('/memory-ui '+JSON.stringify({action:'commit',draftId:draft.id,name:'',pointIds:draft.points.map(p=>p.id),resourceIds:[]}));assert.equal(bad.result.kind,'error');
 const done=await run('/memory-ui '+JSON.stringify({action:'commit',draftId:draft.id,name:'Codex 导入',pointIds:draft.points.map(p=>p.id),resourceIds:[]}));assert.equal(done.result.kind,'success',JSON.stringify(done));assert.equal(ctx.sessionProjections.stateOf(session,'crossSessionMemory').draft,null);
 const listed=await ctx.tools.execute({callId:'list',name:'cross_session_memory',arguments:{action:'list'},agent,signal:new AbortController().signal});
 const id=listed.value.entries[0].id;const exported=await run('/memory-export '+id);assert.equal(exported.result.kind,'success',JSON.stringify(exported));
 console.log('PASS real DSH 0.2.0-rc.2: portable import command -> native naming projection (250 points) -> blank name rejected -> human UI commit -> list -> export command.');
}finally{await ctx.fiber.dispose();await fs.rm(root,{recursive:true,force:true});}
