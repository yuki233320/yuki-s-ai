// Local revision 2.1.1+dsh-local.2: candidate ceiling 500, the shared exchange format's
// own 250-point ceiling, no cancel notice, and the name field's "user named it" flag.
// Host paths run against the BUILT bundle; the client is asserted as a shipped artifact.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import * as host from '../lib/index.js';
import { projection, fold } from '../lib/projection.js';
import { readPortable } from '../src/portable.mjs';
import { mergePoints, CANDIDATE_LIMIT } from '../src/extract.js';

const makePoint = (i) => ({ id:`p${i}`, text:`要点编号 ${i} 的原文句段，未作改写`, category:'fact', source:{ seq:i + 1, role:'user' } });

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes:true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

function harness(draft) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-store-'));
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-project-'));
  const commands = new Map(), tools = new Map(), appended = [];
  let current = draft;
  const ctx = {
    sessionProjections: { register() {}, stateOf: () => ({ draft: current }) },
    commands: { register(spec) { commands.set(spec.name, spec); } },
    tools: { register(spec) { tools.set(spec.name, spec); } },
    systemPrompt: { section() {}, variable() {}, context() {} },
    on() {},
    get() { return undefined; },
  };
  host.apply(ctx, { storageDir: root });
  const agent = { session: { id:`session-${randomUUID()}`, header:{ cwd }, append(type, data) { appended.push({ type, data }); } } };
  const signal = () => new AbortController().signal;
  return {
    root, agent, appended,
    commit(extra = {}) {
      return commands.get('memory-ui').handler({ agent, signal:signal(),
        rawInput: JSON.stringify({ action:'commit', draftId:draft.id, name:'上限测试', pointIds:draft.points.map((p) => p.id), resourceIds:[], ...extra }) });
    },
    exportMemory(id) { return commands.get('memory-export').handler({ agent, rawInput:id }); },
    tool(args) { return tools.get('cross_session_memory').execute(args, { agent, signal:signal() }); },
    portables() { return walk(root).filter((file) => path.basename(file) === 'portable.memory.json'); },
    exchanges() { return walk(root).filter((file) => file.endsWith('.memory.json') && !path.basename(file).startsWith('portable.')); },
  };
}

test('candidate ceiling is 500 and the oldest excess is accounted as omitted', () => {
  assert.equal(CANDIDATE_LIMIT, 500);
  const added = Array.from({ length:600 }, (_, i) => makePoint(i));
  const merged = mergePoints([], added);
  assert.equal(merged.points.length, 500);
  assert.equal(merged.omitted, 100);
  assert.equal(merged.points[0].text, makePoint(100).text, '保留的是最近 500 条');
  assert.equal(merged.points.at(-1).text, makePoint(599).text);
});

test('a 300-point memory is stored whole while the exchange file carries the newest 250 and says so', async () => {
  const points = Array.from({ length:300 }, (_, i) => makePoint(i));
  const h = harness({ id:'draft-big', suggestedName:'大记忆', points, resources:[], omitted:0 });
  const result = await h.commit();
  assert.equal(result.kind, 'success');
  assert.equal(h.appended.at(-1).data.portableTrimmed, 50, '截断条数必须出现在结构化事件里');

  const listed = await h.tool({ action:'list' });
  assert.equal(listed.entries[0].points.length, 300, '本地库必须完整保留 300 条');

  const files = h.portables();
  assert.equal(files.length, 1);
  const doc = readPortable(files[0]);
  assert.equal(doc.points.length, 250);
  assert.equal(doc.extraction.omitted, 50, '被截断的条数要计入 omitted，另一端才看得到原因');
  assert.equal(doc.points.at(-1).text, makePoint(299).text);

  const exported = h.exportMemory(listed.entries[0].id);
  assert.equal(exported.kind, 'success');
  assert.match(exported.text, /仅含最近 250 条要点，另有 50 条未写入/);
  const exchange = h.exchanges();
  assert.equal(exchange.length, 1);
  assert.equal(readPortable(exchange[0]).points.length, 250, '补导出同样遵守共享格式的 250 条上限');
});

test('cancelling leaves no notice behind', () => {
  const state = projection.init({ id:'session-cancel' }, 0);
  const running = fold(state, { seq:5, type:'command/run', data:{ name:'memory-ui', args:JSON.stringify({ action:'cancel' }), commandId:'c1' } });
  assert.equal(running.pending.c1, 'cancel');
  const done = fold(running, { seq:6, type:'command/done', data:{ commandId:'c1', kind:'success', text:'请在记忆弹窗中核对…' } });
  assert.equal(done.notice, '', '取消后不应再显示“已取消，未保存”');
  assert.equal(done.draft, null);
});

test('only a user-supplied name prefills the field', () => {
  const state = projection.init({ id:'session-name' }, 0);
  const opened = fold(state, { seq:3, type:'user/message', data:{ role:'user', source:{ kind:'user' }, content:[{ type:'text', text:'记住这段对话' }] } });
  assert.equal(opened.draft.named, false, '自然语言触发不预填名称');
  assert.equal(opened.draft.suggestedName, '对话记忆');

  const refreshed = fold(opened, { seq:5, type:'command/run', data:{ name:'memory-ui', args:JSON.stringify({ action:'refresh', name:'我的记忆' }), commandId:'c2' } });
  assert.equal(refreshed.draft.named, true, '刷新要带回用户已经输入的名称');
  assert.equal(refreshed.draft.suggestedName, '我的记忆');

  const command = fold(state, { seq:7, type:'command/run', data:{ name:'memory', args:'project "指定名称"', commandId:'c3' } });
  assert.equal(command.draft.named, true);
  assert.equal(command.draft.suggestedName, '指定名称');
});

test('the built client carries the native typography, the ring and the placeholder', () => {
  const client = fs.readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8');
  assert.match(client, /namePlaceholder:'请自定义命名该记忆'/);
  assert.match(client, /placeholder:t\('namePlaceholder'\)/);
  assert.ok(!/autoFocus/.test(client), '有 autoFocus 时 placeholder 一打开就被 :focus 隐藏');
  assert.match(client, /::placeholder\{color:var\(--dsw-alias-label-tertiary/);
  assert.match(client, /:focus::placeholder\{opacity:0\}/);
  assert.match(client, /--dsh-content-font-size-secondary,13px/);
  assert.match(client, /font-variant-numeric:tabular-nums/);
  assert.match(client, /className:'meter'/);
  assert.match(client, /className:'trigger'/);
  assert.match(client, /viewBox:'0 0 14 14'/);
  assert.match(client, /r:'5\.5'/);
  assert.match(client, /rotate\(-90 7 7\)/);
  assert.match(client, /className:'track'/);
  assert.match(client, /className:'fill'/);
});
