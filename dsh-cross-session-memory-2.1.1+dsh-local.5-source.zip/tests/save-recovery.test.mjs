import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as host from '../lib/index.js';
import {projection,fold} from '../lib/projection.js';
import {NamedMemoryStore,projectFor,SelectionFailure} from '../src/store.js';

function setup(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'dsh-save-recovery-'));
  t.after(()=>{if(path.basename(root).startsWith('dsh-save-recovery-')&&path.dirname(root)===path.resolve(os.tmpdir()))fs.rmSync(root,{recursive:true,force:true});});
  const points=[{id:'p',text:'本次决定保存原文信息。',category:'fact',source:{seq:1,role:'user'}}];
  fs.writeFileSync(path.join(root,'good.txt'),'普通测试附件。');
  const resources=['good.txt','missing-a.txt','missing-b.txt'].map((name,i)=>({id:'f'+i,name,kind:'path',path:path.join(root,name),seq:1}));
  let state={...projection.init({id:'test'}),draft:{id:'draft',suggestedName:'',points,resources,omitted:0}};
  let seq=1;const events=[],commands=new Map();
  const agent={session:{id:'test',header:{cwd:root},append(type,data){events.push({type,data});state=fold(state,{type,data,seq:seq++});}}};
  const ctx={sessionProjections:{register(){},stateOf(){return state;}},commands:{register(s){commands.set(s.name,s);}},tools:{register(){}},systemPrompt:{section(){},variable(){},context(){}},on(){},get(){return undefined;}};
  const storageDir=path.join(root,'memory');host.apply(ctx,{storageDir});
  const input={action:'commit',draftId:'draft',name:'恢复测试',pointIds:['p'],resourceIds:['f0','f1','f2'],portable:true};
  const store=new NamedMemoryStore({storageDir}),project=projectFor(agent.session);
  return {root,store,project,input,events,state:()=>state,setState:s=>state=s,commit:(extra={})=>commands.get('memory-ui').handler({agent,rawInput:JSON.stringify({...input,...extra}),signal:new AbortController().signal})};
}
test('all bad attachments are identified, nothing committed until explicit second save',async t=>{
  const h=setup(t);const result=await h.commit();assert.equal(result.kind,'error');
  assert.deepEqual(h.state().draft.recovery.failures.map(f=>f.id),['f1','f2']);
  assert.equal(h.store.read(h.project).entries.length,0);assert.equal(h.events.some(e=>e.type==='memory/saved'),false);
  assert.equal(h.state().draft.id,'draft');assert.equal(h.state().draft.points.length,1);
  projection.stateSchema.parse(h.state());
  const second=await h.commit({resourceIds:['f0']});assert.equal(second.kind,'success');
  const row=h.store.read(h.project).entries[0];assert.equal(row.resources.length,1);assert.equal(row.resources[0].name,'good.txt');
});
test('a sensitive point is identified while name and other points are retained',async t=>{
  const h=setup(t);const s=h.state();s.draft.points.push({id:'bad',text:'password: example-only-test-value',category:'fact',source:{seq:2,role:'user'}});
  assert.equal((await h.commit({pointIds:['p','bad'],resourceIds:[]})).kind,'error');
  assert.deepEqual(h.state().draft.recovery.failures.map(f=>[f.kind,f.id]),[['point','bad']]);
  assert.equal(h.store.read(h.project).entries.length,0);
  assert.equal((await h.commit({pointIds:['p'],resourceIds:[]})).kind,'success');
});
test('directory and oversized file are both attributed without writing a partial memory',async t=>{
  const h=setup(t),large=path.join(h.root,'large.bin');const fd=fs.openSync(large,'w');fs.ftruncateSync(fd,51*1024*1024);fs.closeSync(fd);
  h.state().draft.resources=[{id:'dir',kind:'path',name:'directory',path:h.root,seq:1},{id:'big',kind:'path',name:'large.bin',path:large,seq:1}];
  await h.commit({resourceIds:['dir','big']});assert.deepEqual(h.state().draft.recovery.failures.map(f=>f.id),['dir','big']);
  assert.equal(h.store.read(h.project).entries.length,0);
});
test('destination errors and duplicate names do not uncheck arbitrary selections',async t=>{
  const h=setup(t);await h.commit({resourceIds:['f0']});h.events.length=0;
  const duplicate=await h.commit({resourceIds:['f0']});assert.equal(duplicate.kind,'error');assert.equal(h.events.length,0);
  const invalid=path.join(h.root,'not-a-directory');fs.writeFileSync(invalid,'x');
  const store=new NamedMemoryStore({storageDir:invalid});
  await assert.rejects(()=>store.saveDraft(h.project,h.state().draft,h.input),e=>!(e instanceof SelectionFailure));
});
test('stale or inherited failure events cannot change a new draft',t=>{
  const h=setup(t),s=h.state(),data={draftId:'other',id:'recovery',message:'retry',failures:[{id:'f0',kind:'resource',name:'file',reason:'missing'}]};
  assert.equal(fold(s,{type:'memory/selection-failed',seq:1,data}),s);
  const inherited={...s,inherited:10};assert.equal(fold(inherited,{type:'memory/selection-failed',seq:2,data:{...data,draftId:'draft'}}),inherited);
});
