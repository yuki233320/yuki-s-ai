// Two separate processes verify real command events survive disk persistence.
// Run: node tests/compatibility.host.mjs write <empty fixture directory>
//      node tests/compatibility.host.mjs read  <same fixture directory>
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {zstdCompressSync,zstdDecompressSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import {Context} from '@deepseek-ai/cordis';
import Sessions,{Session,KNOWN_SESSION_EVENT_TYPES} from '@deepseek-ai/dsh-session';
import Projections from '@deepseek-ai/dsh-session-projection';
import SystemPrompt from '@deepseek-ai/dsh-system-prompt';
import Tools from '@deepseek-ai/dsh-tools';
import Commands from '@deepseek-ai/dsh-commands';
import * as plugin from '../lib/index.js';
import {makeProjection} from '../lib/projection.js';
import {NamedMemoryStore,projectFor} from '../src/store.js';

const [mode,dir]=process.argv.slice(2);
assert.ok(mode==='write'||mode==='read');assert.ok(dir);
const root=path.resolve(dir),file=path.join(root,'fixture.v4.jsonl.zstd'),storageDir=path.join(root,'memory');
if(mode==='write'){
  await fs.mkdir(root,{recursive:true});
  await assert.rejects(fs.stat(file));
  await fs.writeFile(path.join(root,'good.txt'),'synthetic attachment');
  const ctx=new Context();
  try{
    await ctx.plugin(Sessions);await ctx.plugin(Projections);await ctx.plugin(SystemPrompt);await ctx.plugin(Tools);await ctx.plugin(Commands);
    await ctx.plugin(plugin,{storageDir});
    const events=[];ctx.on('session/event',(s,e)=>{if(s.id==='compatibility-fixture')events.push(e);});
    const session=ctx.sessions.create('compatibility-fixture',{meta:{cwd:root}}),agent={id:session.id,session};
    session.append('user/message',{id:'u1',role:'user',source:{kind:'user'},content:[{type:'text',text:`决定保留可读附件。\n[good](<${path.join(root,'good.txt')}>)\n[missing](<${path.join(root,'missing.txt')}>)`}]},{surfaceOp:'append'});
    session.append('user/message',{id:'u2',role:'user',source:{kind:'user'},content:[{type:'text',text:'记住这段对话'}]},{surfaceOp:'append'});
    const state=()=>ctx.sessionProjections.stateOf(session,'crossSessionMemory');
    const draft=state().draft;assert.ok(draft);assert.equal(draft.resources.length,2);
    const input={action:'commit',draftId:draft.id,name:'compatibility fixture',pointIds:draft.points.map(p=>p.id),resourceIds:draft.resources.map(r=>r.id)};
    const run=input=>ctx.commands.execute(agent,'/memory-ui '+JSON.stringify(input),[],new AbortController().signal);
    const failed=await run(input);assert.equal(failed.result.kind,'error');assert.equal(state().draft.recovery.failures.length,1);
    const failedId=state().draft.recovery.failures[0].id;
    const saved=await run({...input,resourceIds:input.resourceIds.filter(id=>id!==failedId)});assert.equal(saved.result.kind,'success');assert.equal(state().draft,null);
    await new Promise(resolve=>setImmediate(resolve));
    assert.equal(events.length,session.seq);
    assert.ok(events.every(e=>KNOWN_SESSION_EVENT_TYPES.has(e.type)));
    const text=[session.header,...events].map(r=>JSON.stringify(r)).join('\n')+'\n';
    await fs.writeFile(file,zstdCompressSync(Buffer.from(text)));
    console.log('PASS writer: real failure recovery and confirmed save; only official known event types persisted.');
  }finally{await ctx.fiber.dispose();}
}else{
  const rows=zstdDecompressSync(await fs.readFile(file)).toString('utf8').trim().split('\n').map(JSON.parse),header=rows.shift();
  const persistence=process.env.DSH_PERSISTENCE_ENTRY?await import(pathToFileURL(process.env.DSH_PERSISTENCE_ENTRY).href):await import('@deepseek-ai/dsh-session-persistence');
  persistence.validateStoredEvents(header,rows);
  assert.ok(rows.every(e=>KNOWN_SESSION_EVENT_TYPES.has(e.type)));
  const restored=Session.create(header.id,rows,header,0);assert.equal(restored.deriveMessages().length,2);
  const store=new NamedMemoryStore({storageDir});
  const p=makeProjection({projectOf:h=>projectFor({id:h.id,header:h}),savedFor:(owner,name)=>store.card(owner,name)});
  let state=p.init(header,0),sawRecovery=false;
  for(const event of rows){state=p.apply(state,event);if(state.draft?.recovery)sawRecovery=true;}
  p.stateSchema.parse(state);assert.ok(sawRecovery);assert.equal(state.draft,null);assert.equal(state.lastSaved.name,'compatibility fixture');assert.equal(state.lastSaved.resources,1);
  console.log('PASS fresh-process reader: official stored-event gate, Session reconstruction, recovery replay, and saved address card.');
}
