// Local revision 2.1.1+dsh-local.1: the naming dialog's option decides whether a save
// (or an import landing on disk) also writes the self-contained cross-end file.
// This drives the BUILT host bundle, so the shipped artifact is what is under test.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import * as host from '../lib/index.js';
import { makePortable, writePortable, readPortable } from '../src/portable.mjs';

const point = { id:'p1', text:'本次对话约定：记忆要点只保留原文句段，不添加生成的结论', category:'constraint', source:{ seq:3, role:'user' } };
const sourceRow = { seq:3, role:'user', text:'本次对话约定：记忆要点只保留原文句段，不添加生成的结论' };

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes:true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

/** A live-enough host context: real store, stub services, captured registrations. */
function harness() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-store-'));
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-project-'));
  const commands = new Map(), tools = new Map(), appended = [];
  const baseDraft = { id:'draft-1', suggestedName:'测试记忆', points:[point], resources:[], omitted:0 };
  let current = baseDraft;
  const ctx = {
    sessionProjections: { register() {}, stateOf: () => ({ draft: current }) },
    commands: { register(spec) { commands.set(spec.name, spec); } },
    tools: { register(spec) { tools.set(spec.name, spec); } },
    systemPrompt: { section() {}, variable() {}, context() {} },
    on() {},
    get() { return undefined; },
  };
  host.apply(ctx, { storageDir: root });
  const agent = { session: { id:`session-${randomUUID()}`, header:{ cwd }, append(type, data) { appended.push({ type, data }); } } };
  const signal = () => new AbortController().signal;
  return {
    root, cwd, commands, appended, agent,
    setDraft(draft) { current = draft; },
    commit(extra = {}, draftId = baseDraft.id) {
      return commands.get('memory-ui').handler({ agent, signal:signal(),
        rawInput: JSON.stringify({ action:'commit', draftId, name:'测试记忆', pointIds:['p1'], resourceIds:[], ...extra }) });
    },
    importPortable(file) { return commands.get('memory-import').handler({ agent, rawInput:file }); },
    exportMemory(id) { return commands.get('memory-export').handler({ agent, rawInput:id }); },
    tool(args) { return tools.get('cross_session_memory').execute(args, { agent, signal:signal() }); },
    /** Cross-end files the store itself wrote (excludes any hand-made fixture). */
    portables() { return walk(root).filter(file => path.basename(file) === 'portable.memory.json'); },
  };
}

test('default (option checked) also writes the cross-end file', async () => {
  const h = harness();
  const result = await h.commit();
  assert.equal(result.kind, 'success');
  assert.equal(h.appended.length, 0, '宿主不得再向会话日志追加自定义事件类型');
  const listed = await h.tool({ action:'list' });
  assert.match(listed.entries[0].portablePath, /portable\.memory\.json$/, '通用文件路径必须写进记忆库记录');
  const files = h.portables();
  assert.equal(files.length, 1);
  const doc = readPortable(files[0]);
  assert.equal(doc.name, '测试记忆');
  assert.equal(doc.origin.app, 'dsh');
  assert.equal(doc.points.length, 1);
  assert.equal(doc.points[0].text, point.text);
});

test('explicitly checked behaves exactly like the default', async () => {
  const h = harness();
  const result = await h.commit({ portable:true });
  assert.equal(result.kind, 'success');
  assert.match((await h.tool({ action:'list' })).entries[0].portablePath, /portable\.memory\.json$/);
  assert.equal(h.portables().length, 1);
});

test('unchecked: memory is kept, no cross-end file is written, and /memory-export still produces one', async () => {
  const h = harness();
  const result = await h.commit({ portable:false });
  assert.equal(result.kind, 'success');

  const listed = await h.tool({ action:'list' });
  assert.equal(listed.ok, true);
  assert.equal(listed.total, 1, '记忆本身必须照常保存');
  assert.equal(listed.entries[0].portablePath, undefined, '取消勾选时记录里不应有通用文件路径');
  assert.equal(h.portables().length, 0);
  const id = listed.entries[0].id;

  const exported = h.exportMemory(id);
  assert.equal(exported.kind, 'success');
  const exports = h.portables().concat(walk(h.root).filter(file => file.endsWith('.memory.json') && path.basename(file) !== 'portable.memory.json'));
  assert.equal(exports.length, 1, '取消勾选后必须仍能补导出通用文件');
  const doc = readPortable(exports[0]);
  assert.equal(doc.name, '测试记忆');
  assert.equal(doc.id, id);
});

test('a non-boolean option value is rejected and nothing is stored', async () => {
  const h = harness();
  const result = await h.commit({ portable:'yes' });
  assert.equal(result.kind, 'error');
  assert.match(result.text, /通用记忆文件选项无效/);
  assert.equal(h.portables().length, 0);
  const listed = await h.tool({ action:'list' });
  assert.equal(listed.total, 0);
});

test('the same option governs an import landing on disk', async () => {
  const incoming = path.join(harness().cwd, 'incoming.memory.json');
  const doc = makePortable({
    id:'codex-origin-1', name:'来自 Codex 的记忆', createdAt:'2026-10-03T05:00:00.000Z',
    origin:{ app:'codex', session:'codex-session', project:'C:/codex-project' },
    points:[point], sources:[sourceRow], extraction:{ method:'verbatim', omitted:0 },
  }, 'codex', []);
  writePortable(incoming, doc);

  const off = harness();
  assert.equal(off.importPortable(incoming).kind, 'success');
  // The panel draft is derived, never logged: the same helper the projection fold calls.
  const offCard = host.importCard({ cwd:off.cwd, sourceSession:off.agent.session.id }, incoming);
  off.setDraft({ ...offCard.draft, omitted:0 });
  const offResult = await off.commit({ portable:false, name:'来自 Codex 的记忆' }, offCard.id);
  assert.equal(offResult.kind, 'success');
  assert.equal((await off.tool({ action:'list' })).entries[0].portablePath, undefined);
  assert.equal(off.portables().length, 0);
  assert.equal((await off.tool({ action:'list' })).total, 1);
  assert.equal(off.appended.length, 0, '导入流程同样不得追加自定义事件');

  const on = harness();
  assert.equal(on.importPortable(incoming).kind, 'success');
  const onCard = host.importCard({ cwd:on.cwd, sourceSession:on.agent.session.id }, incoming);
  on.setDraft({ ...onCard.draft, omitted:0 });
  const onResult = await on.commit({ name:'来自 Codex 的记忆' }, onCard.id);
  assert.equal(onResult.kind, 'success');
  assert.match((await on.tool({ action:'list' })).entries[0].portablePath, /portable\.memory\.json$/);
  assert.equal(on.appended.length, 0);
  const written = on.portables();
  assert.equal(written.length, 1);
  assert.equal(readPortable(written[0]).origin.app, 'codex', '导入保留原始来源端');
});

test('the cross-end format module stays byte-compatible with the Codex end', async () => {
  const text = fs.readFileSync(new URL('../src/portable.mjs', import.meta.url), 'utf8');
  assert.match(text, /Shared verbatim between Codex and DSH/);
  const { createHash } = await import('node:crypto');
  assert.equal(createHash('sha256').update(text).digest('hex'), 'd32726d55c505f7029b78f0ad43efadf0ef11a684e5444a6c932cfac314cfa51');
});
