import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as host from '../lib/index.js';
import {makeProjection} from '../lib/projection.js';
import {NamedMemoryStore,projectFor,SelectionFailure} from '../src/store.js';

function setup(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'dsh-recovery6-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.writeFileSync(path.join(root,'good.txt'),'ordinary fixture');
  const points=[{id:'p',text:'本次决定保留可读文件。',category:'fact',source:{seq:0,role:'user'}}];
  const resources=['good.txt','missing-a.txt','missing-b.txt'].map((name,i)=>({id:'f'+i,name,kind:'path',path:path.join(root,name),seq:0}));
  const agent={session:{id:'test',header:{cwd:root},append(){throw Error('Plugin must not append custom events');}}};
  const commands=new Map();let projection,state,seq=1;
  const ctx={sessionProjections:{register(p){projection=p;state=p.init({id:'test',cwd:root});},stateOf(){return state;}},commands:{register(c){commands.set(c.name,c);}},tools:{register(){}},systemPrompt:{section(){},variable(){},context(){}},on(){},get(){}};
  const storageDir=path.join(root,'memory');host.apply(ctx,{storageDir});
  state={...state,draft:{id:'draft',suggestedName:'',points,resources,omitted:0}};
  const input={action:'commit',draftId:'draft',name:'恢复测试',pointIds:['p'],resourceIds:['f0','f1','f2']};
  const store=new NamedMemoryStore({storageDir}),project=projectFor(agent.session);
  async function commit(extra={}){
    const commandId='c'+seq,args=JSON.stringify({...input,...extra});
    state=projection.apply(state,{type:'command/run',seq:seq++,data:{name:'memory-ui',commandId,args}});
    const result=await commands.get('memory-ui').handler({agent,rawInput:args,signal:new AbortController().signal});
    state=projection.apply(state,{type:'command/done',seq:seq++,data:{commandId,...result}});
    projection.stateSchema.parse(state);
    return result;
  }
  return {root,project,store,input,projection,state:()=>state,commit};
}

test('failed selections travel through command results; second user confirmation is required',async t=>{
  const h=setup(t),result=await h.commit();assert.equal(result.kind,'error');
  assert.equal(JSON.parse(result.text).format,'cross-session-memory-selection-failure');
  assert.deepEqual(h.state().draft.recovery.failures.map(f=>f.id),['f1','f2']);
  assert.equal(h.store.read(h.project).entries.length,0);
  assert.equal(h.state().draft.points.length,1);
  const second=await h.commit({resourceIds:['f0']});assert.equal(second.kind,'success');
  assert.equal(h.store.read(h.project).entries[0].resources.length,1);
  assert.equal(h.state().draft,null);
  assert.equal(h.state().lastSaved.name,'恢复测试');
});

test('sensitive point is attributed without losing other selections',async t=>{
  const h=setup(t);h.state().draft.points.push({id:'bad',text:'password: example-only-fixture',category:'fact',source:{seq:0,role:'user'}});
  assert.equal((await h.commit({pointIds:['p','bad'],resourceIds:[]})).kind,'error');
  assert.deepEqual(h.state().draft.recovery.failures.map(f=>[f.kind,f.id]),[['point','bad']]);
  assert.equal(h.store.read(h.project).entries.length,0);
  assert.equal((await h.commit({pointIds:['p'],resourceIds:[]})).kind,'success');
});

test('directory and oversized file remain individually attributed',async t=>{
  const h=setup(t),big=path.join(h.root,'big.bin'),fd=fs.openSync(big,'w');fs.ftruncateSync(fd,51*1024*1024);fs.closeSync(fd);
  h.state().draft.resources=[{id:'dir',kind:'path',name:'directory',path:h.root,seq:0},{id:'big',kind:'path',name:'big.bin',path:big,seq:0}];
  await h.commit({resourceIds:['dir','big']});assert.deepEqual(h.state().draft.recovery.failures.map(f=>f.id),['dir','big']);
  assert.equal(h.store.read(h.project).entries.length,0);
});

test('duplicate and destination errors preserve selections instead of reporting selection failures',async t=>{
  const h=setup(t);await h.commit({resourceIds:['f0']});
  h.state().draft={id:'draft',points:[{id:'p',text:'普通内容',category:'fact',source:{seq:0,role:'user'}}],resources:[],omitted:0,suggestedName:''};
  const result=await h.commit({resourceIds:[]});assert.equal(result.kind,'error');assert.equal(h.state().draft.recovery,undefined);
  const invalid=path.join(h.root,'not-a-directory');fs.writeFileSync(invalid,'x');
  const store=new NamedMemoryStore({storageDir:invalid});await assert.rejects(()=>store.saveDraft(h.project,h.state().draft,{...h.input,resourceIds:[]}),e=>!(e instanceof SelectionFailure));
});

test('stale, malformed and inherited command results cannot uncheck the current draft',t=>{
  const h=setup(t),p=h.projection,base=h.state();
  const payload={format:'cross-session-memory-selection-failure',version:1,draftId:'old',message:'retry',failures:[{kind:'resource',id:'f0',name:'file',reason:'missing'}]};
  const run=p.apply(base,{type:'command/run',seq:1,data:{name:'memory-ui',commandId:'c',args:JSON.stringify({action:'commit',draftId:'old'})}});
  const done=p.apply(run,{type:'command/done',seq:2,data:{commandId:'c',kind:'error',text:JSON.stringify(payload)}});
  assert.equal(done.draft.recovery,undefined);
  const invalid=p.apply({...run,pending:{c:{action:'commit',name:'',draftId:'draft'}}},{type:'command/done',seq:2,data:{commandId:'c',kind:'error',text:JSON.stringify({...payload,draftId:'draft',failures:[{}]})}});
  assert.equal(invalid.draft.recovery,undefined);
  assert.equal(p.apply({...base,inherited:10},{type:'command/run',seq:1,data:{name:'memory-ui',commandId:'c',args:JSON.stringify({action:'commit',draftId:'draft'})}}).pending.c,undefined);
});
