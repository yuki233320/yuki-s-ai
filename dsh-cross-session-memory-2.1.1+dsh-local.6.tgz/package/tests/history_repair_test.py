import importlib.util
import json
import pathlib
import tempfile
import unittest
import zstandard

spec=importlib.util.spec_from_file_location('history_repair',pathlib.Path(__file__).parents[1]/'scripts/repair-history.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class RepairTests(unittest.TestCase):
    def fixture(self,root,version=4,gap=False):
        p=pathlib.Path(root)/'session.v4.jsonl.zstd'
        rows=[{'type':'session','version':version}, {'type':'memory/saved','seq':0,'time':1,'data':{'name':'synthetic'}}, {'type':'unrelated/custom','seq':2 if gap else 1,'time':2,'data':{'keep':True}}]
        frames=[zstandard.ZstdCompressor(write_checksum=True).compress((json.dumps(r)+'\n').encode()) for r in rows]
        p.write_bytes(b''.join(frames));return p,rows,frames
    def test_dry_run_and_apply_preserve_records_and_other_frames(self):
        with tempfile.TemporaryDirectory() as root:
            p,rows,frames=self.fixture(root);original=p.read_bytes()
            dry=module.repair(p,['memory/saved']);self.assertFalse(dry['modified']);self.assertEqual(p.read_bytes(),original)
            result=module.repair(p,['memory/saved'],True);self.assertTrue(result['modified']);self.assertEqual(result['changedFrames'],1)
            self.assertEqual(pathlib.Path(result['backup']).read_bytes(),original)
            with p.open('rb') as source, zstandard.ZstdDecompressor().stream_reader(source) as reader:
                data=reader.read()
            current=[json.loads(line) for line in data.splitlines()]
            self.assertEqual(current[1],{**rows[1],'ignorable':True});self.assertEqual(current[2],rows[2])
            self.assertTrue(p.read_bytes().startswith(frames[0]));self.assertTrue(p.read_bytes().endswith(frames[2]))
            self.assertEqual(module.repair(p,['memory/saved'],True)['events'],[])
    def test_other_types_cannot_be_marked(self):
        with tempfile.TemporaryDirectory() as root:
            p,_,_=self.fixture(root);before=p.read_bytes()
            with self.assertRaises(ValueError):module.repair(p,['unrelated/custom'],True)
            self.assertEqual(p.read_bytes(),before)
    def test_wrong_format_and_sequence_gap_refuse_without_writing(self):
        for version,gap in [(3,False),(4,True)]:
            with self.subTest(version=version,gap=gap),tempfile.TemporaryDirectory() as root:
                p,_,_=self.fixture(root,version,gap);before=p.read_bytes()
                with self.assertRaises(ValueError):module.repair(p,['memory/saved'],True)
                self.assertEqual(p.read_bytes(),before)
    def test_incomplete_frame_refuses_without_writing(self):
        with tempfile.TemporaryDirectory() as root:
            p,_,_=self.fixture(root);before=p.read_bytes()[:-3];p.write_bytes(before)
            with self.assertRaises(Exception):module.repair(p,['memory/saved'],True)
            self.assertEqual(p.read_bytes(),before)

if __name__=='__main__':unittest.main()
