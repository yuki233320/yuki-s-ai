// Local revision 2.1.1+dsh-local.4: the plugin appends no session event of its own.
// A save result reaches the dock's hover-only 「记忆地址」 card by re-reading the store row the
// commit wrote, and an import panel is replayed from the recorded command input — never from a
// custom `memory/*` event. A live `Session.append()` cannot mark an event `ignorable`, and one
// unknown non-ignorable record makes the whole log unreadable at the next open.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import * as host from '../lib/index.js';
import { makeProjection, makeFold } from '../lib/projection.js';
import { NamedMemoryStore, projectFor } from '../src/store.js';

const point = { id:'p1', text:'本次对话约定：保存结果不再常驻输入区，改由悬停卡片承载', category:'decision', source:{ seq:3, role:'user' } };
const card = { id:'mem-1', name:'跨端记忆', points:276, resources:0, file:'C:\\store\\a.json', portablePath:'C:\\store\\assets\\x\\portable.memory.json', portableTrimmed:26 };
const project = { id:'p1', user:'u1', cwd:'C:\\project', sourceSession:'session-address' };

/** A live-enough host: the real store, the projection the plugin registered, and an append spy. */
function harness() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-address-'));
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-cwd-'));
  const commands = new Map(), tools = new Map(), appended = [], projections = [];
  const draft = { id:'draft-1', suggestedName:'地址测试', points:[point], resources:[], omitted:0 };
  const ctx = {
    sessionProjections: { register(spec) { projections.push(spec); }, stateOf: () => ({ draft }) },
    commands: { register(spec) { commands.set(spec.name, spec); } },
    tools: { register(spec) { tools.set(spec.name, spec); } },
    systemPrompt: { section() {}, variable() {}, context() {} },
    on() {},
    get() { return undefined; },
  };
  host.apply(ctx, { storageDir: root });
  const sessionId = `session-${randomUUID()}`;
  const agent = { session: { id:sessionId, header:{ cwd }, append(type, data) { appended.push({ type, data }); } } };
  const signal = () => new AbortController().signal;
  return {
    root, cwd, appended, draft, sessionId,
    header: { id:sessionId, cwd },
    /** The projection the host actually registered, so the real store lookup is under test. */
    projection: projections[0],
    commit(extra = {}) {
      return commands.get('memory-ui').handler({ agent, signal:signal(),
        rawInput: JSON.stringify({ action:'commit', draftId:draft.id, name:'地址测试', pointIds:['p1'], resourceIds:[], ...extra }) });
    },
    tool(args) { return tools.get('cross_session_memory').execute(args, { agent, signal:signal() }); },
    /** An independent read of the same store file: what the card must be rebuilt from. */
    storeCard(name) { return new NamedMemoryStore({ storageDir:root }).card(projectFor({ id:sessionId, header:{ cwd } }), name); },
  };
}

test('a save appends no session event, keeps the command text short and still stores the memory', async () => {
  const h = harness();
  const result = await h.commit();
  assert.equal(result.kind, 'success');
  assert.equal(h.appended.length, 0, '插件不得向会话日志追加任何自定义事件');
  assert.ok(!result.text.includes('位置：'), '命令文案不应再包含记忆库路径');
  assert.ok(!result.text.includes('跨端通用文件：'), '命令文案不应再包含通用文件路径');
  assert.ok(!/[A-Za-z]:\\/.test(result.text), '命令文案不应包含盘符路径');
  assert.ok(result.text.length < 80, '命令文案应当很短');

  const listed = await h.tool({ action:'list' });
  assert.equal(listed.total, 1, '记忆本身要照常入库');
  assert.equal(listed.entries[0].name, '地址测试');
  const stored = h.storeCard('地址测试');
  assert.equal(stored.points, 1);
  assert.equal(stored.resources, 0);
  assert.match(stored.file, /\.json$/);
  assert.match(stored.portablePath, /portable\.memory\.json$/);
  assert.equal(stored.portableTrimmed, 0);
});

test('the projection parks the store card in lastSaved and clears the notice', () => {
  // `savedFor` answers only the named commit: the cold read `init` performs must not pre-fill
  // the card, otherwise this case would pass without the commit path doing any work.
  const p = makeProjection({ projectOf:()=>project, savedFor:(_project, name) => (name === card.name ? card : null) });
  let s = p.init({ id:'session-address' }, 0);
  assert.equal(s.lastSaved, null);
  s = p.apply(s, { seq:3, type:'command/run', data:{ name:'memory', commandId:'c0', args:'project "跨端记忆"' } });
  assert.ok(s.draft, '命名面板应当已经打开');
  s = p.apply(s, { seq:5, type:'command/run', data:{ name:'memory-ui', commandId:'c1', args:JSON.stringify({ action:'commit', name:'跨端记忆' }) } });
  assert.deepEqual(s.pending.c1, { action:'commit', name:'跨端记忆' });
  s = p.apply(s, { seq:6, type:'command/done', data:{ commandId:'c1', kind:'success', text:'已保存“跨端记忆”：276 条原文要点、0 个本地文件。' } });
  assert.deepEqual(s.lastSaved, card, 'lastSaved 必须等于记忆库记录还原出的卡片');
  assert.equal(s.notice, '', '提交后不能再把结果贴到输入区');
  assert.equal(s.draft, null);
  assert.deepEqual(s.pending, {});
});

test('a failing commit surfaces the error and leaves the existing card untouched', () => {
  const p = makeProjection({ projectOf:()=>project, savedFor:()=>card });
  let s = p.init({ id:'session-error' }, 0);
  assert.deepEqual(s.lastSaved, card, '冷启动已从记忆库还原的卡片');
  s = p.apply(s, { seq:5, type:'command/run', data:{ name:'memory-ui', commandId:'c1', args:JSON.stringify({ action:'commit', name:'跨端记忆' }) } });
  s = p.apply(s, { seq:6, type:'command/done', data:{ commandId:'c1', kind:'error', text:'请输入 1–100 字符的记忆名称。' } });
  assert.match(s.notice, /请输入 1–100 字符的记忆名称/);
  assert.deepEqual(s.lastSaved, card, '失败不得清掉或改写已有卡片');
  assert.deepEqual(s.pending, {});
});

test('the registered projection rebuilds the card from the row a real commit wrote', async () => {
  const h = harness();
  let s = h.projection.init(h.header, 0);
  assert.equal(s.lastSaved, null, '本次项目还没有保存记录');
  assert.equal(s.project.id, projectFor({ id:h.sessionId, header:{ cwd:h.cwd } }).id, '投影必须绑定真实项目身份');

  const result = await h.commit();
  assert.equal(result.kind, 'success');
  const expected = h.storeCard('地址测试');
  assert.ok(expected, '提交后记忆库必须能还原出卡片');

  s = h.projection.apply(s, { seq:7, type:'command/run', data:{ name:'memory-ui', commandId:'c1', args:JSON.stringify({ action:'commit', name:'地址测试' }) } });
  s = h.projection.apply(s, { seq:8, type:'command/done', data:{ commandId:'c1', kind:'success', text:result.text } });
  assert.deepEqual(s.lastSaved, expected, '卡片必须来自记忆库记录，而不是会话日志');
  assert.equal(s.notice, '');
  assert.equal(s.draft, null);
  assert.equal(h.appended.length, 0, '还原卡片同样不依赖任何自定义事件');

  // A restart re-runs init against the same store: the audit trail restores the card without
  // replaying a single event of this session.
  const restarted = h.projection.init(h.header, 0);
  assert.deepEqual(restarted.lastSaved, expected, '重启后 init 必须从审计记录找回卡片');
  assert.equal(restarted.draft, null);
});

test('the card survives a restart: init rebuilds it from the store with no event replay', () => {
  const p = makeProjection({ projectOf:() => ({ ...project }), savedFor:() => card });
  const state = p.init({ id:'session-cold' }, 0);
  assert.deepEqual(state.lastSaved, card, '重启后卡片不能丢');
  assert.equal(state.notice, '');
});

test('a memory saved without the exchange file still yields a card with portablePath null', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-memory-noportable-'));
  const store = new NamedMemoryStore({ storageDir:path.join(dir, 'memory') });
  const owner = projectFor({ id:`session-${randomUUID()}`, header:{ cwd:dir } });
  const draft = { id:'d1', points:[point], resources:[], omitted:0 };
  const result = await store.saveDraft(owner, draft, { draftId:'d1', name:'仅本地', pointIds:['p1'], resourceIds:[], portable:false });
  assert.equal(result.portablePath, undefined);
  const saved = store.card(owner, '仅本地');
  assert.equal(saved.portablePath, null, '未生成通用文件时卡片要能区分');
  assert.equal(saved.portableTrimmed, 0);
  assert.equal(saved.points, 1);
  assert.equal(saved.resources, 0);
  assert.deepEqual(store.card(owner), saved, '无名称的冷读取用审计记录找到本会话最后写入的那条');
});

test('the import panel comes from the recorded command path and never from a logged event', () => {
  const importDraft = { id:'i1', suggestedName:'导入', points:[], resources:[], omitted:0, imported:true };
  const seen = [];
  const p = makeProjection({ projectOf:()=>project, importOf:(proj, raw) => { seen.push([proj, raw]); return { id:'i1', doc:{ name:'导入' }, draft:importDraft }; } });
  const s = p.init({ id:'session-import' }, 0);
  const next = p.apply(s, { seq:4, type:'command/run', data:{ name:'memory-import', commandId:'c1', args:'"C:\\tmp\\a.memory.json"' } });
  assert.deepEqual(seen, [[project, '"C:\\tmp\\a.memory.json"']], '面板由 command/run 记录的文件路径重放得出');
  assert.match(next.notice, /请核对导入记忆的名称/);
  assert.equal(next.draft, importDraft, 'draft 必须就是 importOf 给出的草稿');
});

test('a failing import lookup degrades to “no panel” and leaves the state untouched', () => {
  const p = makeProjection({ projectOf:()=>project, importOf:() => { throw new Error('记忆文件无法读取'); } });
  const s = p.init({ id:'session-import' }, 0);
  const next = p.apply(s, { seq:4, type:'command/run', data:{ name:'memory-import', commandId:'c1', args:'C:\\tmp\\broken.memory.json' } });
  assert.equal(next, s, '异常必须降级为无面板，而不是抛出或改写状态');
  assert.equal(next.notice, '');
  assert.equal(next.draft, null);
});

test('init without a project lookup stays null and never throws', () => {
  const p = makeProjection();
  assert.equal(p.key, 'crossSessionMemory');
  assert.equal(p.stateVersion, 4);
  const s = p.init({ id:'x' }, 0);
  assert.equal(s.project, null);
  assert.equal(s.lastSaved, null);
  assert.equal(p.stateSchema.safeParse(s).success, true);
  // Without a usable cwd the real lookup throws; init must swallow it and keep project null.
  const q = makeProjection({ projectOf:header => projectFor({ id:header?.id, header }) });
  assert.equal(q.init({ id:'x' }, 0).project, null);
});

test('the built host bundle appends no session event of its own', () => {
  const bundle = fs.readFileSync(new URL('../lib/index.js', import.meta.url), 'utf8');
  assert.ok(!bundle.includes('memory/saved'), '不得再出现自定义会话事件 memory/saved');
  assert.ok(!bundle.includes('memory/portable-import'), '不得再出现自定义会话事件 memory/portable-import');
  assert.ok(!/\.session\.append\(/.test(bundle), '宿主 bundle 不得调用 session.append');
});

test('no shipped source or built module declares a custom session event', () => {
  const offenders = [];
  for (const dir of ['../src/', '../lib/']) {
    const base = new URL(dir, import.meta.url);
    for (const name of fs.readdirSync(base)) {
      if (!/\.(?:js|mjs)$/.test(name)) continue;
      const text = fs.readFileSync(new URL(name, base), 'utf8');
      for (const event of ['memory/saved', 'memory/portable-import', 'memory/selection-failed']) if (text.includes(event)) offenders.push(`${dir}${name}: ${event}`);
      if (/\.session\.append\(/.test(text)) offenders.push(`${dir}${name}: .session.append(`);
    }
  }
  assert.deepEqual(offenders, [], '仓库内不该再有任何自定义会话事件');
});

test('the built client renders a hover-only address card', () => {
  const client = fs.readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8');
  assert.match(client, /address:'记忆地址'/);
  assert.match(client, /memoryFile:'记忆库文件'/);
  assert.match(client, /portableFile:'跨端通用文件'/);
  assert.match(client, /copyAddress:'复制地址'/);
  assert.match(client, /className:'address'/);
  assert.match(client, /className:'card'/);
  assert.match(client, /onMouseEnter:openAddress/);
  assert.match(client, /onMouseLeave:closeAddress/);
  assert.match(client, /copyAddress/);
  assert.match(client, /\.dsh-memory \.card\{position:fixed/);
  assert.match(client, /setTimeout\(\(\)=>setFlash\(''\),6000\)/, '瞬时确认必须自动消失');
  assert.match(client, /rotate\(-90 7 7\)/, '上一轮的原生环形进度不能被破坏');
  assert.match(client, /namePlaceholder:'请自定义命名该记忆'/);
  assert.match(client, /onMouseOver:holdAddress/, '指针进入卡片必须取消关闭');
  assert.match(client, /closeTimer\.current=setTimeout/, '离开只能延时关闭');
  assert.match(client, /closeAddressNow/, 'Esc 与真正失焦仍要立即关闭');
  assert.match(client, /\.dsh-memory \.card:hover\{background:var\(--dsw-alias-bg-layer-1/, '悬停时必须换成原生不透明底色');
});
