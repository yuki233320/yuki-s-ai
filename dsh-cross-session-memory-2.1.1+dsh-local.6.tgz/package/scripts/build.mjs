import {build} from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const result=await build({entryPoints:[path.join(root,'src/index.js'),path.join(root,'src/projection.js')],outdir:path.join(root,'lib'),bundle:true,platform:'node',format:'esm',target:'node22',legalComments:'eof',write:false});
fs.mkdirSync(path.join(root,'lib'),{recursive:true});
for(const output of result.outputFiles)fs.writeFileSync(output.path,output.contents);
fs.copyFileSync(path.join(root,'src/client.js'),path.join(root,'lib/client.js'));
