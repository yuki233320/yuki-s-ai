"""Explicit, backed-up repair for informational events from this plugin.

Requires Python 3.9+ and zstandard. Default is read-only dry-run.
Close all DSH instances before --apply. This is not a general unknown-event bypass.
"""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import tempfile
import zstandard

ALLOWED = {'memory/saved', 'memory/portable-import', 'memory/selection-failed'}

def repair(file, types, apply=False):
    file = pathlib.Path(file).resolve(strict=True)
    if not file.is_file() or file.name != 'session.v4.jsonl.zstd':
        raise ValueError('Select one session.v4.jsonl.zstd file')
    if not types or not set(types) <= ALLOWED:
        raise ValueError('Only explicitly selected informational events from this plugin are supported')
    original = file.read_bytes()
    rest, frames, replacements, rows, changed = original, [], [], [], []
    while rest:
        decoder = zstandard.ZstdDecompressor().decompressobj()
        plain = decoder.decompress(rest)
        if not decoder.eof:
            raise ValueError('Incomplete Zstandard frame; no changes made')
        consumed = len(rest) - len(decoder.unused_data)
        if consumed <= 0 or not plain.endswith(b'\n'):
            raise ValueError('Unexpected frame or line boundary; no changes made')
        compressed = rest[:consumed]
        rest = decoder.unused_data
        lines = plain.splitlines(keepends=True)
        touched = False
        for i, line in enumerate(lines):
            row = json.loads(line)
            rows.append(row)
            if row.get('type') not in types or row.get('ignorable') is True:
                continue
            if 'ignorable' in row:
                raise ValueError('Unexpected existing ignorable value; manual review required')
            trimmed = line.rstrip()
            if not trimmed.endswith(b'}'):
                raise ValueError('Unexpected event object')
            updated = trimmed[:-1] + b',"ignorable":true}' + line[len(trimmed):]
            if json.loads(updated) != {**row, 'ignorable': True}:
                raise ValueError('Record preservation check failed')
            lines[i] = updated
            changed.append({'type': row['type'], 'seq': row['seq']})
            touched = True
        frames.append(compressed)
        replacements.append(zstandard.ZstdCompressor(write_checksum=True).compress(b''.join(lines)) if touched else compressed)
    if not rows or rows[0].get('type') != 'session' or rows[0].get('version') != 4:
        raise ValueError('Only same-format V4 history is supported')
    if [r.get('seq') for r in rows[1:]] != list(range(len(rows)-1)):
        raise ValueError('Sequence discontinuity; no changes made')
    report = {'mode': 'apply' if apply else 'dry-run', 'events': changed,
              'frames': len(frames), 'changedFrames': sum(a != b for a,b in zip(frames,replacements)),
              'records': len(rows), 'modified': False}
    if not apply or not changed:
        return report
    candidate = b''.join(replacements)
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup = file.with_name(file.name + '.bak-' + stamp)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=file.parent, prefix=file.name+'.repair-', delete=False) as f:
            temporary = pathlib.Path(f.name)
            f.write(candidate); f.flush(); os.fsync(f.fileno())
        if hashlib.sha256(file.read_bytes()).digest() != hashlib.sha256(original).digest():
            raise ValueError('History changed during inspection; stop DSH and retry')
        with backup.open('xb') as f:
            f.write(original); f.flush(); os.fsync(f.fileno())
        shutil.copystat(file, backup)
        if file.read_bytes() != original:
            raise ValueError('History changed; original retained and backup created')
        os.replace(temporary, file); temporary = None
        report.update(modified=True, backup=str(backup))
        return report
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--file', required=True)
    parser.add_argument('--event', action='append', required=True, choices=sorted(ALLOWED))
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    print(json.dumps(repair(args.file,args.event,args.apply),ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
